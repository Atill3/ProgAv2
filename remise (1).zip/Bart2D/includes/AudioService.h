#pragma once

#include <IAudio.h>
#include <Windows.h>
#include <MMSystem.h>
#include <map>

using namespace std;
namespace bart
{
	class AudioService final : public IAudio
	{
	public:
		bool Initialize() override;
		void Destroy() override;

		size_t LoadSound(const string & filename) override;
		void UnloadSound(size_t id) override;
		void GetSound(size_t id) override;
	private:
		
		

			
	};
}