#include <Bart2d.h>
#include <SdlGraphics.h>
#include <SDL.h>

bool bart::SdlGraphics::Initialize()
{
	if(SDL_Init(SDL_INIT_EVERYTHING) < 0)
	{
		// LOG
		return false;
	}

	m_ClearColor = new SDL_Color{ 61, 61, 61, 255 };
	return true;
}

void bart::SdlGraphics::Destroy()
{
	SDL_DestroyRenderer(m_Renderer);
	SDL_DestroyWindow(m_Window);

	m_Renderer = nullptr;
	m_Window = nullptr;

	SDL_Quit();
}

bool bart::SdlGraphics::InitWindow(const string& title, int w, int h, EWindowState state)
{
	m_Window = SDL_CreateWindow(
		title.c_str(),
		SDL_WINDOWPOS_CENTERED,
		SDL_WINDOWPOS_CENTERED,
		w, h, SDL_WINDOW_BORDERLESS);

	if(m_Window == nullptr)
	{
		// LOG
		return false;
	}

	m_Renderer = SDL_CreateRenderer(m_Window, -1, SDL_RENDERER_ACCELERATED);

	if(m_Renderer == nullptr)
	{
		// LOG
		return false;
	}

	if(state == EWindowState::BORDERLESS)
	{
		SDL_SetWindowFullscreen(m_Window, SDL_WINDOW_FULLSCREEN_DESKTOP);
	}
	else if(state == EWindowState::FULLSCREEN)
	{
		SDL_SetWindowFullscreen(m_Window, SDL_WINDOW_FULLSCREEN);
	}

	return true;
}

void bart::SdlGraphics::Clear()
{
	SDL_SetRenderDrawColor(
		m_Renderer,
		m_ClearColor->r,
		m_ClearColor->g,
		m_ClearColor->b,
		255);

	SDL_RenderClear(m_Renderer);
	SDL_SetRenderDrawColor(m_Renderer, 0, 0, 0, 255);
}

void bart::SdlGraphics::Present()
{
	SDL_RenderPresent(m_Renderer);
}

void bart::SdlGraphics::SetColor(unsigned char r, unsigned char g, unsigned char b)
{
	SetColor(r, g, b, 255);
}

void bart::SdlGraphics::SetColor(unsigned char r, unsigned char g, unsigned char b, unsigned char a)
{
	SDL_SetRenderDrawColor(m_Renderer, r, g, b, a);
}

void bart::SdlGraphics::SetClearColor(unsigned char r, unsigned char g, unsigned char b, unsigned char a)
{
	m_ClearColor->r = r;
	m_ClearColor->g = g;
	m_ClearColor->b = b;
	m_ClearColor->a = a;
}

void bart::SdlGraphics::DrawRect(float x, float y, float w, float h)
{
}

void bart::SdlGraphics::FillRect(float x, float y, float w, float h)
{
}

void bart::SdlGraphics::DrawCircle(float x, float y, float r)
{
	float tX = x;
	float tY = y;

	const double inc = 0.01;
	const double circle = 6.63;
	double angle = 0.0;

	while(angle < circle)
	{
		tX = static_cast<float>(x + r * cos(angle));
		tY = static_cast<float>(y + r * sin(angle));
		DrawPoint(tX, tY);

		angle += inc;
	}
}

void bart::SdlGraphics::DrawPoint(float x, float y)
{
	const int tX = static_cast<int>(x);
	const int tY = static_cast<int>(y);
	SDL_RenderDrawPoint(m_Renderer, tX, tY);
}

void bart::SdlGraphics::DrawLine(float x1, float y1, float x2, float y2)
{
}

void bart::SdlGraphics::SetWindowState(EWindowState state)
{
}
