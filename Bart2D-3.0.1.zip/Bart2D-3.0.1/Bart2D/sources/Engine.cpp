#include <Bart2d.h>
#include <Engine.h>
#include <cassert>
#include <EWindowState.h>
#include <SdlGraphics.h>

bart::Engine& bart::Engine::Get()
{
	static Engine instance;
	return instance;
}

bool bart::Engine::Initialize()
{
	m_GraphicService = new SdlGraphics();
	bool result = m_GraphicService->Initialize();
	assert(result);

	result = m_GraphicService->InitWindow("MyGame", 800, 600, WINDOWED);
	assert(result);

	m_IsInitialized = true;
	return true;
}

void bart::Engine::Start()
{
	if(m_IsInitialized && !m_IsRunning)
	{
		m_IsRunning = true;
		while(m_IsRunning)
		{
			m_GraphicService->Clear();
			m_GraphicService->SetColor(255, 0, 0);
			m_GraphicService->DrawCircle(400.0f, 300.0f, 50.0f);
			m_GraphicService->Present();
		}

		Destroy();
	}
}

void bart::Engine::Stop()
{
	m_IsRunning = false;
}

void bart::Engine::Destroy()
{
	if(m_GraphicService != nullptr)
	{
		m_GraphicService->Destroy();
		delete m_GraphicService;
		m_GraphicService = nullptr;
	}
}
