#pragma once

#include <IGraphics.h>

namespace bart
{
	class Engine
	{
	public:
		static Engine& Get();

		bool Initialize();
		void Start();
		void Stop();

		IGraphics& Graphics() const { return *m_GraphicService; }

	private:
		Engine() = default;
		~Engine() = default;

		void Destroy();

		bool m_IsInitialized = false;
		bool m_IsRunning = false;

		IGraphics* m_GraphicService = nullptr;
	};
}
