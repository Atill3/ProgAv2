# Documentation



## Liste des composants fournit dans l'engin

### Animation

**filename** : le fichier .anim pour cette animation

```xml
<!-- Dans un fichier .prefab -->
<animation filename="assets/une_animation.anim"/>
```

Variable d'éditeur

play : si cette option est coché, l'animation débute automatiquement

clip : le nom de l'animation à jouer

loop : si cette option est coché, l'animation va jouer en boucle.

color : change la couleur de l'image de l'animation

