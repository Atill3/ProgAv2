#include <Music.h>
#include <Engine.h>
#include <tinyxml.h>

void Music::Load(const string& filename)
{
	m_MusicId = Engine::Get().Audio().LoadMusic(filename);
}

void Music::Play()
{
	Play(-1);
}

void Music::Play(const int loop)
{
	m_Playing = true;
	Engine::Get().Audio().PlayMusic(m_MusicId, loop);
}

void Music::Pause() const
{
	Engine::Get().Audio().PauseMusic();
}

void Music::Stop()
{
	m_Playing = false;
	Engine::Get().Audio().StopMusic();
}

void Music::Resume() const
{
	Engine::Get().Audio().ResumeMusic();
}

void Music::SetVolume(const int volume) const
{
	Engine::Get().Audio().SetVolume(volume);
}

void Music::OnEnable()
{
	if (m_Playing)
	{
		Resume();
	}
}

void Music::OnDisable()
{
	if (m_Playing)
	{
		Pause();
	}
}

void Music::Destroy()
{
	Stop();
}

void MusicFactory::Create(Entity* entity, XMLElement* element, Properties& props)
{
	Music* music = entity->AddComponent<Music>();
	const string filename = element->Attribute("filename");
	music->Load(filename);

	if (props.HasProperty("volume"))
	{
		const int volume = props.GetInt("volume");
		music->SetVolume(volume);
	}

	const bool play = props.GetBool("play");
	if (play)
	{
		const bool loop = props.GetBool("loop");
		music->Play(loop ? -1 : 1);
	}
}
