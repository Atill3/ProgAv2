#include <Animation.h>
#include <Entity.h>
#include <tinyxml.h>
#include "Engine.h"

void bart::Animation::InitAnimation(const int frameInRows, const int frameWidth, const int frameHeight)
{
	m_FrameInRowCount = frameInRows;
	m_FrameWidth = frameWidth;
	m_FrameHeight = frameHeight;
}

void bart::Animation::AddClip(const string& name, const int start, const int count, const float delay)
{
	m_Frames.emplace(name, AnimationFrame{start, count, delay});
}

void bart::Animation::Stop()
{
	m_Playing = false;
	m_CurrentFrame = 0;
	m_FirstFrame = 0;
	m_LastFrame = 0;
	m_Delay = 0.0f;
	m_Loop = false;
}

void bart::Animation::Update(const float deltaTime)
{
	Sprite::Update(deltaTime);

	if (m_Playing)
	{
		m_Elapsed += deltaTime;
		if (m_Elapsed >= m_Delay)
		{
			m_Elapsed = 0.0f;
			m_CurrentFrame++;
			if (m_CurrentFrame > m_LastFrame)
			{
				m_CurrentFrame = m_FirstFrame;
				if (!m_Loop)
				{
					m_Playing = false;
				}
			}

			UpdateFrame();
		}
	}
}

void bart::Animation::Render()
{
	if (m_Playing)
	{
		Sprite::Render();
	}
}

void bart::Animation::Play(const string& name, const bool loop)
{
	const AnimationFrame frame = m_Frames[name];
	m_CurrentFrame = frame.start;
	m_FirstFrame = frame.start;
	m_LastFrame = frame.start + frame.count - 1;
	m_Delay = frame.delay;
	m_Loop = loop;

	UpdateFrame();
	m_Playing = true;
}

void bart::Animation::UpdateFrame()
{
	const int row = m_CurrentFrame / m_FrameInRowCount;
	const int col = m_CurrentFrame - m_FrameInRowCount * row;
	const int x = m_FrameWidth * col;
	const int y = m_FrameHeight * row;
	m_Source.Set(x, y, m_FrameWidth, m_FrameHeight);
}

void bart::Animation::LoadFromFile(const string& filename)
{
	XMLDocument document;
	if(document.LoadFile(filename.c_str()) == XML_SUCCESS)
	{
		XMLNode* node = document.FirstChild();
		if(node)
		{
			XMLElement* elem = node->ToElement();
			const int rows = elem->IntAttribute("rows");
			const int width = elem->IntAttribute("frameWidth");
			const int height = elem->IntAttribute("frameHeight");
			InitAnimation(rows, width, height);

			XMLNode* child = node->FirstChild();
			while(child)
			{
				string value = child->Value();
				if(value.compare("texture") == 0)
				{
					XMLElement* texElem = child->ToElement();
					const char* texture = texElem->Attribute("filename");
					Load(texture);
				}
				else if(value.compare("clips") == 0)
				{
					XMLNode* clip = child->FirstChild();
					while(clip)
					{
						XMLElement* clipElem = clip->ToElement();
						const char* name = clipElem->Attribute("name");
						const int first = clipElem->IntAttribute("first");
						const int count = clipElem->IntAttribute("count");
						const float delay = clipElem->FloatAttribute("delay");
						AddClip(name, first, count, delay);
						clip = clip->NextSibling();
					}
				}

				child = child->NextSibling();
			}
		}
	}
	else
	{
		Engine::Get().Logger().LogError(string(document.ErrorStr()));
	}
}

void bart::AnimationFactory::Create(Entity* entity, XMLElement* element, Properties& props)
{
	Animation* anim = entity->AddComponent<Animation>();
	const string filename = element->Attribute("filename");
	anim->LoadFromFile(filename);

	if (props.HasProperty("play"))
	{
		const bool play = props.GetBool("play");
		if (play)
		{
			const string clip = props.GetString("clip");
			const bool loop = props.GetBool("loop");
			anim->Play(clip, loop);
		}
	}

	const Color color = props.GetColor("color");
	anim->SetColor(color);
}
