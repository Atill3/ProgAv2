#include <Box2dPhysics.h>
#include <Dynamics/b2World.h>
#include <Dynamics/b2Body.h>
#include <Dynamics/b2Fixture.h>
#include <Collision/Shapes/b2PolygonShape.h>
#include <Collision/Shapes/b2CircleShape.h>
#include <Dynamics/b2WorldCallbacks.h>
#include <Engine.h>
#include <iostream>
#include <Dynamics/Contacts/b2Contact.h>
#include <PhysicMaterial.h>
#include <Entity.h>
#include <EContactType.h>
#include <ContactInfo.h>

/*
 *  http://www.box2d.org/manual.html
 *
 *  NOTES:
 *  - The suggested iteration count for Box2D is 8 for velocity and 3 for position.
 *  - Generally physics engines for games like a time step at least as fast as 60Hz or 1/60 seconds.
 *  - http://www.iforce2d.net/b2dtut
 */
const float32 bart::Box2dPhysics::WORLD_SCALE = 30.0f;
const float32 bart::Box2dPhysics::WORLD_SCALE_INV = 1.0f / WORLD_SCALE;
const float32 bart::Box2dPhysics::TIME_STEP = 1.0f / 60.0f;
const int32 bart::Box2dPhysics::VELOCITY_ITERATION = 8;
const int32 bart::Box2dPhysics::POSITION_ITERATION = 3;

b2BodyType GetB2DBodyType(const bart::EBodyType aType)
{
	switch (aType)
	{
	case bart::DYNAMIC_BODY:
		return b2_dynamicBody;
	case bart::STATIC_BODY:
		return b2_staticBody;
	case bart::KINEMATIC_BODY:
		return b2_kinematicBody;
	}

	return b2_staticBody;
}

class ContactListener final : public b2ContactListener
{
public:
	virtual ~ContactListener() = default;
	void BeginContact(b2Contact* aContact) override;
	void EndContact(b2Contact* aContact) override;
};

void ContactListener::BeginContact(b2Contact* aContact)
{
	const b2Manifold* _manifold = aContact->GetManifold();

	b2WorldManifold _worldManifold;
	aContact->GetWorldManifold(&_worldManifold);

	b2Fixture* tFixtureA = aContact->GetFixtureA();
	b2Fixture* tFixtureB = aContact->GetFixtureB();

	b2Body* tBodyA = tFixtureA->GetBody();
	b2Body* tBodyB = tFixtureB->GetBody();

	bart::Entity* tEntityA = static_cast<bart::Entity*>(tBodyA->GetUserData());
	bart::Entity* tEntityB = static_cast<bart::Entity*>(tBodyB->GetUserData());

	if (tEntityA && tEntityB && aContact->IsTouching())
	{
		bart::ContactInfo* tInfo = new bart::ContactInfo();
		tInfo->ContactType = bart::BEGIN_CONTACT;
		tInfo->EntityA = tEntityA;
		tInfo->EntityB = tEntityB;

		bart::IPhysic& tPhysic = bart::Engine::Get().Physics();
		for (int i = 0; i < _manifold->pointCount; i++)
		{
			tInfo->ContactPoints.push_back(
				{
					tPhysic.ToWorld(_worldManifold.points[i].x),
					tPhysic.ToWorld(_worldManifold.points[i].y)
				});
		}

		tInfo->NormalX = _worldManifold.normal.x;
		tInfo->NormalY = _worldManifold.normal.y;
		tPhysic.AddContactInfo(tInfo);
	}
}

void ContactListener::EndContact(b2Contact* aContact)
{
	b2Fixture* tFixtureA = aContact->GetFixtureA();
	b2Fixture* tFixtureB = aContact->GetFixtureB();

	b2Body* tBodyA = tFixtureA->GetBody();
	b2Body* tBodyB = tFixtureB->GetBody();

	bart::Entity* tEntityA = static_cast<bart::Entity*>(tBodyA->GetUserData());
	bart::Entity* tEntityB = static_cast<bart::Entity*>(tBodyB->GetUserData());

	if (tEntityA && tEntityB && !aContact->IsTouching())
	{
		bart::IPhysic& tPhysic = bart::Engine::Get().Physics();

		bart::ContactInfo* tInfo = new bart::ContactInfo();
		tInfo->ContactType = bart::END_CONTACT;
		tInfo->EntityA = tEntityA;
		tInfo->EntityB = tEntityB;
		tPhysic.AddContactInfo(tInfo);
	}
}

class RayCastCallback : public b2RayCastCallback
{
public:
	RayCastCallback() = default;
	virtual ~RayCastCallback() = default;

	bool IsColliding() const { return m_object.size() > 0; }
	std::vector<bart::RayCastInfo> GetCollidingObjects() const { return m_object; }
	void Clear() { m_object.clear(); }

protected:
	RayCastCallback(const RayCastCallback&) = default;
	RayCastCallback& operator=(const RayCastCallback&) = default;
	std::vector<bart::RayCastInfo> m_object;
};

class RaycastAllListener final : public RayCastCallback
{
public:
	RaycastAllListener() = default;
	virtual ~RaycastAllListener() = default;

	float32 ReportFixture(b2Fixture* fixture, const b2Vec2& point, const b2Vec2& normal, float32 fraction) override;

private:
	RaycastAllListener(const RaycastAllListener&) = default;
	RaycastAllListener& operator=(const RaycastAllListener&) = default;
};

class RaycastFirstListener final : public RayCastCallback
{
public:
	RaycastFirstListener() = default;
	virtual ~RaycastFirstListener() = default;

	float32 ReportFixture(b2Fixture* fixture, const b2Vec2& point, const b2Vec2& normal, float32 fraction) override;

private:
	RaycastFirstListener(const RaycastFirstListener&) = default;
	RaycastFirstListener& operator=(const RaycastFirstListener&) = default;
};

RayCastCallback* gRayCastFirstCallback = new RaycastFirstListener();
RayCastCallback* gRayCastAllCallback = new RaycastAllListener();

// --------------------------------------------------------------------------------------------------------------------
//   ___       _ _   _       _ _
//  |_ _|_ __ (_) |_(_) __ _| (_)_______
//   | || '_ \| | __| |/ _` | | |_  / _ \
//   | || | | | | |_| | (_| | | |/ /  __/
//  |___|_| |_|_|\__|_|\__,_|_|_/___\___|
//
//  \brief Initialize Box2D's world
//  \return true if the initialization is successful
//
bool bart::Box2dPhysics::Initialize()
{
	const b2Vec2 tGravity = { 0.0f, 10.0f };
	m_physicWorld = new b2World(tGravity);
	m_physicWorld->SetContactListener(new ContactListener());
	m_running = true;
	return true;
}

// --------------------------------------------------------------------------------------------------------------------
//    ____ _
//   / ___| | ___  __ _ _ __
//  | |   | |/ _ \/ _` | '_ \
//  | |___| |  __/ (_| | | | |
//   \____|_|\___|\__,_|_| |_|
//
//  \brief Clean up the resources used for Box2D
//
void bart::Box2dPhysics::Destroy()
{
	for (TBodyMap::iterator tItr = m_bodyList.begin(); tItr != m_bodyList.end(); ++tItr)
	{
		tItr->second->Body->DestroyFixture(tItr->second->Fixture);
		m_physicWorld->DestroyBody(tItr->second->Body);
		delete tItr->second;
	}

	m_bodyList.clear();

	m_running = false;

	b2ContactListener* tListener = m_physicWorld->GetContactManager().m_contactListener;

	if (tListener != nullptr)
	{
		delete tListener;
		tListener = nullptr;
	}

	if (m_physicWorld != nullptr)
	{
		delete m_physicWorld;
		m_physicWorld = nullptr;
	}

	if (gRayCastAllCallback != nullptr)
	{
		delete gRayCastAllCallback;
		gRayCastAllCallback = nullptr;
	}

	if (gRayCastFirstCallback != nullptr)
	{
		delete gRayCastFirstCallback;
		gRayCastFirstCallback = nullptr;
	}
}

// --------------------------------------------------------------------------------------------------------------------
//   _____  __        __         _     _
//  |_   _|_\ \      / /__  _ __| | __| |
//    | |/ _ \ \ /\ / / _ \| '__| |/ _` |
//    | | (_) \ V  V / (_) | |  | | (_| |
//    |_|\___/ \_/\_/ \___/|_|  |_|\__,_|
//
//  \brief Converts a number from physic to the world space
//  \param aValue the value to convert to world space
//  \return the value converted from physic to world space
//
float bart::Box2dPhysics::ToWorld(const float aValue)
{
	return aValue * WORLD_SCALE;
}

// --------------------------------------------------------------------------------------------------------------------
//   _____     ____  _               _
//  |_   _|__ |  _ \| |__  _   _ ___(_) ___
//    | |/ _ \| |_) | '_ \| | | / __| |/ __|
//    | | (_) |  __/| | | | |_| \__ \ | (__
//    |_|\___/|_|   |_| |_|\__, |___/_|\___|
//                         |___/
//  \brief Converts a number from world to the physic space
//  \param aValue the value to convert to physic space
//  \return the value converted from world to physic space
//
float bart::Box2dPhysics::ToPhysic(const float aValue)
{
	return aValue * WORLD_SCALE_INV;
}

// --------------------------------------------------------------------------------------------------------------------
//   ____       _    ____                 _ _
//  / ___|  ___| |_ / ___|_ __ __ ___   _(_) |_ _   _
//  \___ \ / _ \ __| |  _| '__/ _` \ \ / / | __| | | |
//   ___) |  __/ |_| |_| | | | (_| |\ V /| | |_| |_| |
//  |____/ \___|\__|\____|_|  \__,_| \_/ |_|\__|\__, |
//                                              |___/
//  \brief Sets the gravity force vector. Note this will wake up all bodies when called.
//  \param aX force in the x axis
//  \param aY force in the y axis
//
void bart::Box2dPhysics::SetGravity(const float aX, const float aY)
{
	const b2Vec2 tGravity = { aX, aY };
	m_physicWorld->SetGravity(tGravity);
	Awake(true);
}

// --------------------------------------------------------------------------------------------------------------------
//      _                _
//     / \__      ____ _| | _____
//    / _ \ \ /\ / / _` | |/ / _ \
//   / ___ \ V  V / (_| |   <  __/
//  /_/   \_\_/\_/ \__,_|_|\_\___|
//
//  \brief Wakes up or puts to sleep all bodies in the world
//  \param aValue indicates if we'll wake up or go to sleep
//
void bart::Box2dPhysics::Awake(const bool aValue)
{
	b2Body* tBody = m_physicWorld->GetBodyList();
	while (tBody != nullptr)
	{
		tBody->SetAwake(aValue);
		tBody = tBody->GetNext();
	}
}

// --------------------------------------------------------------------------------------------------------------------
//    ____                _       ____            _
//   / ___|_ __ ___  __ _| |_ ___| __ )  ___   __| |_   _
//  | |   | '__/ _ \/ _` | __/ _ \  _ \ / _ \ / _` | | | |
//  | |___| | |  __/ (_| | ||  __/ |_) | (_) | (_| | |_| |
//   \____|_|  \___|\__,_|\__\___|____/ \___/ \__,_|\__, |
//                                                  |___/
//  \brief Creates and add a body in the world
//  \param aMaterial contains all the information needed to initialize the body
//  \return an Id to find back the body in the body list
//
size_t bart::Box2dPhysics::CreateBody(const PhysicMaterial& aMaterial)
{
	size_t tId = 0;

	if (m_physicWorld)
	{
		const float tHalfWidth = ToPhysic(aMaterial.Width) * 0.5f;
		const float tHalfHeight = ToPhysic(aMaterial.Height) * 0.5f;

		b2BodyDef tBodyDef;
		tBodyDef.userData = aMaterial.BodyUserData;

		tBodyDef.position.x = ToPhysic(aMaterial.PosX) + tHalfWidth;
		tBodyDef.position.y = ToPhysic(aMaterial.PosY) + tHalfHeight;

		tBodyDef.angle = aMaterial.Angle;
		tBodyDef.linearVelocity.Set(aMaterial.VelocityX, aMaterial.VelocityY);
		tBodyDef.angularVelocity = aMaterial.AngularVelocity;
		tBodyDef.linearDamping = aMaterial.Damping;
		tBodyDef.angularDamping = aMaterial.AngularDamping;
		tBodyDef.allowSleep = aMaterial.AllowSleep;
		tBodyDef.awake = aMaterial.Awake;
		tBodyDef.fixedRotation = aMaterial.FixedRotation;
		tBodyDef.bullet = aMaterial.Bullet;
		tBodyDef.type = GetB2DBodyType(aMaterial.BodyType);
		tBodyDef.active = aMaterial.Active;
		tBodyDef.gravityScale = aMaterial.GravityScale;

		b2Body* tBody = m_physicWorld->CreateBody(&tBodyDef);
		tId = reinterpret_cast<size_t>(tBody);

		m_bodyList[tId] = new Box2dBodyInfo();
		m_bodyList[tId]->Body = tBody;
		m_bodyList[tId]->Width = aMaterial.Width;
		m_bodyList[tId]->Height = aMaterial.Height;
		m_bodyList[tId]->HalfWidth = tHalfWidth;
		m_bodyList[tId]->HalfHeight = tHalfHeight;

		b2FixtureDef tFixtureDef;

		if (aMaterial.Shape == RECTANGLE_SHAPE)
		{
			b2PolygonShape* tPolygonShape = new b2PolygonShape();
			tPolygonShape->SetAsBox(tHalfWidth, tHalfHeight);
			tFixtureDef.shape = tPolygonShape;
		}
		else if (aMaterial.Shape == CIRCLE_SHAPE)
		{
			b2CircleShape* tCircleShape = new b2CircleShape();
			tCircleShape->m_radius = std::max<float>(tHalfWidth, tHalfHeight);
			tFixtureDef.shape = tCircleShape;
		}

		tFixtureDef.userData = aMaterial.FixtureUserData;
		tFixtureDef.friction = aMaterial.Friction;
		tFixtureDef.restitution = aMaterial.Restitution;
		tFixtureDef.density = aMaterial.Density;
		tFixtureDef.isSensor = aMaterial.Sensor;

		m_bodyList[tId]->Fixture = tBody->CreateFixture(&tFixtureDef);

		if (tFixtureDef.shape != nullptr)
		{
			delete tFixtureDef.shape;
			tFixtureDef.shape = nullptr;
		}
	}

	return tId;
}

// --------------------------------------------------------------------------------------------------------------------
//    ____      _  _____                     __
//   / ___| ___| ||_   _| __ __ _ _ __  ___ / _| ___  _ __ _ __ ___
//  | |  _ / _ \ __|| || '__/ _` | '_ \/ __| |_ / _ \| '__| '_ ` _ \
//  | |_| |  __/ |_ | || | | (_| | | | \__ \  _| (_) | |  | | | | | |
//   \____|\___|\__||_||_|  \__,_|_| |_|___/_|  \___/|_|  |_| |_| |_|
//
//  \brief Gets the body's transform. You need to update your visuals to fit Box2D's transforms
//  \param aId the body's id
//  \param aX the body's x position
//  \param aY the body's y position
//  \param aAngle the body's rotation angle in degrees
//
void bart::Box2dPhysics::GetTransform(const size_t aId, float* aX, float* aY, float* aAngle)
{
	if (m_bodyList.count(aId) > 0)
	{
		b2Body* tBody = m_bodyList[aId]->Body;
		if (tBody != nullptr)
		{
			const b2Vec2 tPosition = tBody->GetPosition();
			*aX = ToWorld(tPosition.x - m_bodyList[aId]->HalfWidth);
			*aY = ToWorld(tPosition.y - m_bodyList[aId]->HalfHeight);
			*aAngle = tBody->GetAngle() * Engine::Get().Maths().TO_DEGREES;
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------
//   ____       _  _____                     __
//  / ___|  ___| ||_   _| __ __ _ _ __  ___ / _| ___  _ __ _ __ ___
//  \___ \ / _ \ __|| || '__/ _` | '_ \/ __| |_ / _ \| '__| '_ ` _ \
//   ___) |  __/ |_ | || | | (_| | | | \__ \  _| (_) | |  | | | | | |
//  |____/ \___|\__||_||_|  \__,_|_| |_|___/_|  \___/|_|  |_| |_| |_|
//
//  \brief Sets the body's transform.
//  \param aId the body's id
//  \param aX the body's x position
//  \param aY the body's y position
//  \param aAngle the body's rotation angle in degrees
//
void bart::Box2dPhysics::SetTransform(const size_t aId, const float aX, const float aY, const float aAngle)
{
	if (m_bodyList.count(aId))
	{
		const float tX = ToPhysic(aX) + m_bodyList[aId]->HalfWidth;
		const float tY = ToPhysic(aY) + m_bodyList[aId]->HalfHeight;
		m_bodyList[aId]->Body->SetTransform({ tX, tY }, aAngle * Engine::Get().Maths().TO_RADIANS);

		// https://github.com/erincatto/Box2D/issues/357
		m_bodyList[aId]->Body->SetAwake(true);
	}
}

// --------------------------------------------------------------------------------------------------------------------
//      _                _       ___                       _
//     / \   _ __  _ __ | |_   _|_ _|_ __ ___  _ __  _   _| |___  ___
//    / _ \ | '_ \| '_ \| | | | || || '_ ` _ \| '_ \| | | | / __|/ _ \
//   / ___ \| |_) | |_) | | |_| || || | | | | | |_) | |_| | \__ \  __/
//  /_/   \_\ .__/| .__/|_|\__, |___|_| |_| |_| .__/ \__,_|_|___/\___|
//          |_|   |_|      |___/              |_|
//
//  \brief Applies a linear impulse to a body
//  \param aId the body's id
//  \param aX direction and magnitude of the impulse in the x axis
//  \param aY direction and magnitude of the impulse in the y axis
//  \param aWorld apply the impulse in world or local space
//
void bart::Box2dPhysics::ApplyImpulse(const size_t aId, const float aX, const float aY, const bool aWorld)
{
	if (m_bodyList.count(aId))
	{
		b2Vec2 tForce = { aX, aY };

		if (aWorld)
		{
			tForce = m_bodyList[aId]->Body->GetWorldVector(tForce);
		}

		if (m_bodyList[aId]->Body->GetType() != b2_staticBody)
		{
			m_bodyList[aId]->Body->ApplyLinearImpulse(tForce, m_bodyList[aId]->Body->GetWorldCenter());
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------
//      _                _       _____
//     / \   _ __  _ __ | |_   _|  ___|__  _ __ ___ ___
//    / _ \ | '_ \| '_ \| | | | | |_ / _ \| '__/ __/ _ \
//   / ___ \| |_) | |_) | | |_| |  _| (_) | | | (_|  __/
//  /_/   \_\ .__/| .__/|_|\__, |_|  \___/|_|  \___\___|
//          |_|   |_|      |___/
//
//  \brief Applies a force to a body
//  \param aId the body's id
//  \param aX direction and magnitude of the force in the x axis
//  \param aY direction and magnitude of the force in the y axis
//  \param aWorld apply the force in world or local space
//
void bart::Box2dPhysics::ApplyForce(const size_t aId, const float aX, const float aY, const bool aWorld)
{
	if (m_bodyList.count(aId))
	{
		b2Vec2 tForce = { aX, aY };

		if (aWorld)
		{
			tForce = m_bodyList[aId]->Body->GetWorldVector(tForce);
		}

		if (m_bodyList[aId]->Body->GetType() != b2_staticBody)
		{
			m_bodyList[aId]->Body->ApplyForce(tForce, m_bodyList[aId]->Body->GetWorldCenter());
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------
//      _                _      _____
//     / \   _ __  _ __ | |_   |_   _|__  _ __ __ _ _   _  ___
//    / _ \ | '_ \| '_ \| | | | || |/ _ \| '__/ _` | | | |/ _ \
//   / ___ \| |_) | |_) | | |_| || | (_) | | | (_| | |_| |  __/
//  /_/   \_\ .__/| .__/|_|\__, ||_|\___/|_|  \__, |\__,_|\___|
//          |_|   |_|      |___/                 |_|
//
//  \brief Apply torque to a body
//  \param aId the body's id
//  \param aTorque the amount of torque to apply to the body
//
void bart::Box2dPhysics::ApplyTorque(const size_t aId, const float aTorque)
{
	if (m_bodyList.count(aId))
	{
		if (m_bodyList[aId]->Body->GetType() != b2_staticBody)
		{
			m_bodyList[aId]->Body->ApplyTorque(aTorque);
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------
//      _                _          _                      _           ___                       _
//     / \   _ __  _ __ | |_   _   / \   _ __   __ _ _   _| | __ _ _ _|_ _|_ __ ___  _ __  _   _| |___  ___
//    / _ \ | '_ \| '_ \| | | | | / _ \ | '_ \ / _` | | | | |/ _` | '__| || '_ ` _ \| '_ \| | | | / __|/ _ \
//   / ___ \| |_) | |_) | | |_| |/ ___ \| | | | (_| | |_| | | (_| | |  | || | | | | | |_) | |_| | \__ \  __/
//  /_/   \_\ .__/| .__/|_|\__, /_/   \_\_| |_|\__, |\__,_|_|\__,_|_| |___|_| |_| |_| .__/ \__,_|_|___/\___|
//          |_|   |_|      |___/               |___/                                |_|
//
//  \brief Apply an angular impulse to a body. If Torque is the equivalent of force for rotation, this is the
//         equivalent of impulse for rotation.
//  \param aId the body's id
//  \param aImpulse the impulse to apply
//
void bart::Box2dPhysics::ApplyAngularImpulse(const size_t aId, const float aImpulse)
{
	if (m_bodyList.count(aId))
	{
		if (m_bodyList[aId]->Body->GetType() != b2_staticBody)
		{
			m_bodyList[aId]->Body->ApplyAngularImpulse(aImpulse);
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------
//   ____            _                   ____            _
//  |  _ \  ___  ___| |_ _ __ ___  _   _| __ )  ___   __| |_   _
//  | | | |/ _ \/ __| __| '__/ _ \| | | |  _ \ / _ \ / _` | | | |
//  | |_| |  __/\__ \ |_| | | (_) | |_| | |_) | (_) | (_| | |_| |
//  |____/ \___||___/\__|_|  \___/ \__, |____/ \___/ \__,_|\__, |
//                                 |___/                   |___/
//
//  \brief Destroys a body and removes it from the world
//  \param aId the body's id
//
void bart::Box2dPhysics::DestroyBody(const size_t aId)
{
	if (m_bodyList.count(aId))
	{
		b2Body* tBody = m_bodyList[aId]->Body;
		delete m_bodyList[aId];
		m_bodyList.erase(aId);
		m_scheduledBodyRemoval.insert(tBody);
	}
}

// --------------------------------------------------------------------------------------------------------------------
//   ____            _                   _____ _      _
//  |  _ \  ___  ___| |_ _ __ ___  _   _|  ___(_)_  _| |_ _   _ _ __ ___
//  | | | |/ _ \/ __| __| '__/ _ \| | | | |_  | \ \/ / __| | | | '__/ _ \
//  | |_| |  __/\__ \ |_| | | (_) | |_| |  _| | |>  <| |_| |_| | | |  __/
//  |____/ \___||___/\__|_|  \___/ \__, |_|   |_/_/\_\\__|\__,_|_|  \___|
//                                 |___/
//
//  \brief Destroys a Fixture from a body. Ex: Updating the shape's definition.
//
void bart::Box2dPhysics::DestroyFixture(const size_t aId)
{
	if (m_bodyList.count(aId))
	{
		m_scheduledFixtureRemoval.insert(m_bodyList[aId]->Fixture);
		m_bodyList[aId]->Fixture = nullptr;
	}
}

// --------------------------------------------------------------------------------------------------------------------
//    ____      _   ____            _        ____                  _
//   / ___| ___| |_| __ )  ___   __| |_   _ / ___|___  _   _ _ __ | |_
//  | |  _ / _ \ __|  _ \ / _ \ / _` | | | | |   / _ \| | | | '_ \| __|
//  | |_| |  __/ |_| |_) | (_) | (_| | |_| | |__| (_) | |_| | | | | |_
//   \____|\___|\__|____/ \___/ \__,_|\__, |\____\___/ \__,_|_| |_|\__|
//                                    |___/
//
//  \brief Gets how much bodies are in the physic world
//  \return the number of bodies in the world
//
size_t bart::Box2dPhysics::GetBodyCount()
{
	if (m_physicWorld != nullptr)
	{
		return m_physicWorld->GetBodyCount();
	}

	return 0;
}

// --------------------------------------------------------------------------------------------------------------------
//   _   _           _       _
//  | | | |_ __   __| | __ _| |_ ___
//  | | | | '_ \ / _` |/ _` | __/ _ \
//  | |_| | |_) | (_| | (_| | ||  __/
//   \___/| .__/ \__,_|\__,_|\__\___|
//        |_|
//
//  \brief Updates the physic world
//
void bart::Box2dPhysics::Update()
{
	if (m_running)
	{
		m_physicWorld->Step(TIME_STEP, VELOCITY_ITERATION, POSITION_ITERATION);

		for (std::list<ContactInfo*>::iterator tItr = m_contactList.begin(); tItr != m_contactList.end(); ++tItr)
		{
			if ((*tItr)->ContactType == BEGIN_CONTACT)
			{
				(*tItr)->EntityA->OnCollisionEnter((*tItr)->EntityB, (*tItr)->ContactPoints, (*tItr)->NormalX, (*tItr)->NormalY);
				(*tItr)->EntityB->OnCollisionEnter((*tItr)->EntityA, (*tItr)->ContactPoints, (*tItr)->NormalX, (*tItr)->NormalY);
			}
			else if ((*tItr)->ContactType == END_CONTACT)
			{
				(*tItr)->EntityA->OnCollisionExit((*tItr)->EntityB);
				(*tItr)->EntityB->OnCollisionExit((*tItr)->EntityA);
			}

			delete* tItr;
		}

		m_contactList.clear();

		if (m_scheduledFixtureRemoval.size() > 0)
		{
			std::set<b2Fixture*>::iterator _itt = m_scheduledFixtureRemoval.begin();
			const std::set<b2Fixture*>::iterator _end = m_scheduledFixtureRemoval.end();

			while (_itt != _end)
			{
				(*_itt)->GetBody()->DestroyFixture(*_itt);
				++_itt;
			}

			m_scheduledFixtureRemoval.clear();
		}

		if (m_scheduledBodyRemoval.size() > 0)
		{
			std::set<b2Body*>::iterator _itt = m_scheduledBodyRemoval.begin();
			const std::set<b2Body*>::iterator _end = m_scheduledBodyRemoval.end();

			while (_itt != _end)
			{
				m_physicWorld->DestroyBody(*_itt);
				++_itt;
			}

			m_scheduledBodyRemoval.clear();
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------
//   ____       _    ____                 _ _         ____            _
//  / ___|  ___| |_ / ___|_ __ __ ___   _(_) |_ _   _/ ___|  ___ __ _| | ___
//  \___ \ / _ \ __| |  _| '__/ _` \ \ / / | __| | | \___ \ / __/ _` | |/ _ \
//   ___) |  __/ |_| |_| | | | (_| |\ V /| | |_| |_| |___) | (_| (_| | |  __/
//  |____/ \___|\__|\____|_|  \__,_| \_/ |_|\__|\__, |____/ \___\__,_|_|\___|
//                                              |___/
//
void bart::Box2dPhysics::SetGravityScale(const size_t aId, const float aScale)
{
	if (m_bodyList.count(aId))
	{
		b2Body* tBody = m_bodyList[aId]->Body;
		tBody->SetGravityScale(aScale);
		tBody->SetAwake(true);
	}
}

// --------------------------------------------------------------------------------------------------------------------
//    ____      _   __  __
//   / ___| ___| |_|  \/  | __ _ ___ ___
//  | |  _ / _ \ __| |\/| |/ _` / __/ __|
//  | |_| |  __/ |_| |  | | (_| \__ \__ \
//   \____|\___|\__|_|  |_|\__,_|___/___/
//
//
float bart::Box2dPhysics::GetMass(const size_t aId)
{
	if (m_bodyList.count(aId))
	{
		b2Body* tBody = m_bodyList[aId]->Body;
		return tBody->GetMass();
	}

	return 0.0f;
}

// --------------------------------------------------------------------------------------------------------------------
//   ____       _   __  __
//  / ___|  ___| |_|  \/  | __ _ ___ ___
//  \___ \ / _ \ __| |\/| |/ _` / __/ __|
//   ___) |  __/ |_| |  | | (_| \__ \__ \
//  |____/ \___|\__|_|  |_|\__,_|___/___/
//
//
void bart::Box2dPhysics::SetMass(const size_t aId, const float aMass)
{
	if (m_bodyList.count(aId))
	{
		b2Body* tBody = m_bodyList[aId]->Body;
		b2MassData* tMass = new b2MassData();
		tMass->center = tBody->GetWorldCenter();
		tMass->mass = aMass;
		tBody->SetMassData(tMass);
	}
}

// --------------------------------------------------------------------------------------------------------------------
//   _____ _      ____       _        _   _
//  |  ___(_)_  _|  _ \ ___ | |_ __ _| |_(_) ___  _ __
//  | |_  | \ \/ / |_) / _ \| __/ _` | __| |/ _ \| '_ \
//  |  _| | |>  <|  _ < (_) | || (_| | |_| | (_) | | | |
//  |_|   |_/_/\_\_| \_\___/ \__\__,_|\__|_|\___/|_| |_|
//
//
void bart::Box2dPhysics::FixRotation(const size_t aId, const bool aFixed)
{
	if (m_bodyList.count(aId))
	{
		b2Body* tBody = m_bodyList[aId]->Body;
		tBody->SetFixedRotation(aFixed);
	}
}

// --------------------------------------------------------------------------------------------------------------------
//    ____      _ __     __   _            _ _
//   / ___| ___| |\ \   / /__| | ___   ___(_) |_ _   _
//  | |  _ / _ \ __\ \ / / _ \ |/ _ \ / __| | __| | | |
//  | |_| |  __/ |_ \ V /  __/ | (_) | (__| | |_| |_| |
//   \____|\___|\__| \_/ \___|_|\___/ \___|_|\__|\__, |
//                                               |___/
//
void bart::Box2dPhysics::GetVelocity(const size_t aId, float* aX, float* aY)
{
	if (m_bodyList.count(aId))
	{
		b2Body* tBody = m_bodyList[aId]->Body;
		const b2Vec2 tVelociy = tBody->GetLinearVelocity();
		*aX = tVelociy.x;
		*aY = tVelociy.y;
	}
}

// --------------------------------------------------------------------------------------------------------------------
//   ____       _ __     __   _            _ _
//  / ___|  ___| |\ \   / /__| | ___   ___(_) |_ _   _
//  \___ \ / _ \ __\ \ / / _ \ |/ _ \ / __| | __| | | |
//   ___) |  __/ |_ \ V /  __/ | (_) | (__| | |_| |_| |
//  |____/ \___|\__| \_/ \___|_|\___/ \___|_|\__|\__, |
//                                               |___/
//
void bart::Box2dPhysics::SetVelocity(const size_t aId, const float aX, const float aY)
{
	if (m_bodyList.count(aId))
	{
		b2Body* tBody = m_bodyList[aId]->Body;
		tBody->SetLinearVelocity({ aX, aY });
	}
}

// --------------------------------------------------------------------------------------------------------------------
//   ____       _   _____     _      _   _
//  / ___|  ___| |_|  ___| __(_) ___| |_(_) ___  _ __
//  \___ \ / _ \ __| |_ | '__| |/ __| __| |/ _ \| '_ \
//   ___) |  __/ |_|  _|| |  | | (__| |_| | (_) | | | |
//  |____/ \___|\__|_|  |_|  |_|\___|\__|_|\___/|_| |_|
//
//
void bart::Box2dPhysics::SetFriction(const size_t aId, const float aFriction)
{
	if (m_bodyList.count(aId))
	{
		m_bodyList[aId]->Fixture->SetFriction(aFriction);
	}
}

// --------------------------------------------------------------------------------------------------------------------
//   ____       _   _____ _ _ _            _
//  / ___|  ___| |_|  ___(_) | |_ ___ _ __(_)_ __   __ _
//  \___ \ / _ \ __| |_  | | | __/ _ \ '__| | '_ \ / _` |
//   ___) |  __/ |_|  _| | | | ||  __/ |  | | | | | (_| |
//  |____/ \___|\__|_|   |_|_|\__\___|_|  |_|_| |_|\__, |
//                                                 |___/
//
void bart::Box2dPhysics::SetFiltering(const size_t aId, signed short aIndex, unsigned short aCategory, unsigned short aMask)
{
	if (m_bodyList.count(aId))
	{
		b2Filter tFilter;
		tFilter.categoryBits = aCategory;
		tFilter.maskBits = aMask;
		tFilter.groupIndex = aIndex;

		m_bodyList[aId]->Fixture->SetFilterData(tFilter);
	}
}

// --------------------------------------------------------------------------------------------------------------------
//   ____       _   ____
//  / ___|  ___| |_/ ___|  ___ _ __  ___  ___  _ __
//  \___ \ / _ \ __\___ \ / _ \ '_ \/ __|/ _ \| '__|
//   ___) |  __/ |_ ___) |  __/ | | \__ \ (_) | |
//  |____/ \___|\__|____/ \___|_| |_|___/\___/|_|
//
//
void bart::Box2dPhysics::SetSensor(const size_t aId, bool aSensor)
{
	if (m_bodyList.count(aId))
	{
		m_bodyList[aId]->Fixture->SetSensor(aSensor);
	}
}

// --------------------------------------------------------------------------------------------------------------------
//   ____       _   ____           _   _ _         _   _
//  / ___|  ___| |_|  _ \ ___  ___| |_(_) |_ _   _| |_(_) ___  _ __
//  \___ \ / _ \ __| |_) / _ \/ __| __| | __| | | | __| |/ _ \| '_ \
//   ___) |  __/ |_|  _ <  __/\__ \ |_| | |_| |_| | |_| | (_) | | | |
//  |____/ \___|\__|_| \_\___||___/\__|_|\__|\__,_|\__|_|\___/|_| |_|
//
//
void bart::Box2dPhysics::SetRestitution(const size_t aId, float aRestitution)
{
	if (m_bodyList.count(aId))
	{
		m_bodyList[aId]->Fixture->SetRestitution(aRestitution);
	}
}
                                                      
void bart::Box2dPhysics::SetAngularVelocity(const size_t aId, const float aVelocity)
{
	if (m_bodyList.count(aId))
	{
		m_bodyList[aId]->Body->SetAngularVelocity(aVelocity);
	}
}

float bart::Box2dPhysics::GetAngularVelocity(const size_t aId)
{
	if (m_bodyList.count(aId))
	{
		return m_bodyList[aId]->Body->GetAngularVelocity();
	}

	return 0.0f;
}

void bart::Box2dPhysics::ClearWorld()
{
	for (TBodyMap::iterator tItr = m_bodyList.begin(); tItr != m_bodyList.end(); ++tItr)
	{
		m_scheduledBodyRemoval.insert(tItr->second->Body);
		delete tItr->second;
	}

	m_bodyList.clear();
}

void bart::Box2dPhysics::AddContactInfo(ContactInfo* aContactInfo)
{
	m_contactList.push_back(aContactInfo);
}

std::vector<bart::RayCastInfo> bart::Box2dPhysics::RayCast(float aX1, float aY1, float aX2, float aY2, bool aOnlyFirstHit)
{
	if (std::abs(aX2 - aX1) || std::abs(aY2 - aY1))
	{
		const b2Vec2 tPointA(ToPhysic(aX1), ToPhysic(aY1));
		const b2Vec2 tPointB(ToPhysic(aX2), ToPhysic(aY2));

		if (aOnlyFirstHit)
		{
			gRayCastFirstCallback->Clear();
			m_physicWorld->RayCast(gRayCastFirstCallback, tPointA, tPointB);
			return gRayCastFirstCallback->GetCollidingObjects();
		}

		gRayCastAllCallback->Clear();
		m_physicWorld->RayCast(gRayCastAllCallback, tPointA, tPointB);
		return gRayCastAllCallback->GetCollidingObjects();
	}

	return {};
}

//---------------------------------------------------------------------------------------------------------------------
float32 RaycastAllListener::ReportFixture(b2Fixture* fixture, const b2Vec2& point, const b2Vec2& normal, float32 fraction)
{
	///     - return -1: ignore this fixture and continue
	///     - return 0: terminate the ray cast
	///     - return fraction: clip the ray to this point
	///     - return 1: don't clip the ray and continue
	void* _data = fixture->GetBody()->GetUserData();
	if (_data)
	{
		bart::Entity* tEntity = static_cast<bart::Entity*>(_data);

		bart::IPhysic& tPhysic = bart::Engine::Get().Physics();

		bart::RayCastInfo _obj;
		_obj.Entity = tEntity;
		_obj.PointX = tPhysic.ToWorld(point.x);
		_obj.PointY = tPhysic.ToWorld(point.y);
		_obj.NormalX = tPhysic.ToWorld(normal.x);
		_obj.NormalY = tPhysic.ToWorld(normal.y);
		m_object.push_back(_obj);
	}

	return 1.0f;
}

//---------------------------------------------------------------------------------------------------------------------
float32 RaycastFirstListener::ReportFixture(b2Fixture* fixture, const b2Vec2& point, const b2Vec2& normal, float32 fraction)
{
	///     - return -1: ignore this fixture and continue
	///     - return 0: terminate the ray cast
	///     - return fraction: clip the ray to this point
	///     - return 1: don't clip the ray and continue
	void* _data = fixture->GetBody()->GetUserData();
	if (_data)
	{
		bart::Entity* tEntity = static_cast<bart::Entity*>(_data);

		bart::IPhysic& tPhysic = bart::Engine::Get().Physics();

		bart::RayCastInfo _obj;
		_obj.Entity = tEntity;
		_obj.PointX = tPhysic.ToWorld(point.x);
		_obj.PointY = tPhysic.ToWorld(point.y);
		_obj.NormalX = tPhysic.ToWorld(normal.x);
		_obj.NormalY = tPhysic.ToWorld(normal.y);
		m_object.push_back(_obj);
	}

	return 0.0f;
}