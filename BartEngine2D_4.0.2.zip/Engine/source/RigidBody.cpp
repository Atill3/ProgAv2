#include <RigidBody.h>
#include <Engine.h>
#include <cassert>
#include <Entity.h>
#include "tinyxml2.h"

void RigidBody::Set(const EBodyType aBody, const EShapeType aShape)
{
	m_Body = aBody;
	m_Shape = aShape;
}

void RigidBody::Update(float aDelta)
{
	Engine::Get().Physics().GetTransform(
		m_bodyId, &m_Transform->m_Destination.x, &m_Transform->m_Destination.y, &m_Transform->angle);
}

void RigidBody::Start()
{
	m_Transform = m_Owner->GetComponent<Transform>();
	assert(m_Transform);

	if (m_bodyId <= 0)
	{
		m_Material.BodyType = m_Body;
		m_Material.Shape = m_Shape;
		m_Material.Width = m_Transform->m_Destination.width;
		m_Material.Height = m_Transform->m_Destination.height;
		m_Material.PosX = m_Transform->m_Destination.x;
		m_Material.PosY = m_Transform->m_Destination.y;
		m_Material.BodyUserData = m_Owner;
		m_bodyId = Engine::Get().Physics().CreateBody(m_Material);
	}
}

void RigidBodyFactory::Create(Entity* entity, XMLElement* element, Properties& props)
{
	RigidBody* rigidBody = entity->AddComponent<RigidBody>();

	const unsigned char body = static_cast<unsigned char>(element->IntAttribute("body"));
	const unsigned char shape = static_cast<unsigned char>(element->IntAttribute("shape"));
	rigidBody->Set(static_cast<EBodyType>(body), static_cast<EShapeType>(shape));

	if(props.HasProperty("gravityScale"))
	{
		const float gravityScale = props.GetFloat("gravityScale");
		rigidBody->SetGravityScale(gravityScale);
	}

	if (props.HasProperty("mass"))
	{
		const float mass = props.GetFloat("mass");
		rigidBody->SetMass(mass);
	}

	if (props.HasProperty("friction"))
	{
		const float friction = props.GetFloat("friction");
		rigidBody->SetFriction(friction);
	}

	if (props.HasProperty("sensor"))
	{
		const bool sensor = props.GetBool("sensor");
		rigidBody->SetSensor(sensor);
	}

	if (props.HasProperty("restitution"))
	{
		const float restitution = props.GetFloat("restitution");
		rigidBody->SetRestitution(restitution);
	}
}

void RigidBody::ApplyImpulse(const float aX, const float aY, const bool aWorld) const
{
	Engine::Get().Physics().ApplyImpulse(m_bodyId, aX, aY, aWorld);
}

void RigidBody::ApplyForce(const float aX, const float aY, const bool aWorld) const
{
	Engine::Get().Physics().ApplyForce(m_bodyId, aX, aY, aWorld);
}

void RigidBody::ApplyAngularImpulse(const float aImpulse) const
{
	Engine::Get().Physics().ApplyAngularImpulse(m_bodyId, aImpulse);
}

void RigidBody::ApplyTorque(const float aTorque) const
{
	Engine::Get().Physics().ApplyTorque(m_bodyId, aTorque);
}

void RigidBody::SetGravityScale(const float aScale) const
{
	Engine::Get().Physics().SetGravityScale(m_bodyId, aScale);
}

float RigidBody::GetMass() const
{
	return Engine::Get().Physics().GetMass(m_bodyId);
}

void RigidBody::SetMass(const float aMass) const
{
	Engine::Get().Physics().SetMass(m_bodyId, aMass);
}

void RigidBody::FixRotation(const bool aFixed) const
{
	Engine::Get().Physics().FixRotation(m_bodyId, aFixed);
}

void RigidBody::GetVelocity(float* aX, float* aY) const
{
	Engine::Get().Physics().GetVelocity(m_bodyId, aX, aY);
}

void RigidBody::SetVelocity(const float aX, const float aY) const
{
	Engine::Get().Physics().SetVelocity(m_bodyId, aX, aY);
}

void RigidBody::SetAngularVelocity(const float aVelocity) const
{
	Engine::Get().Physics().SetAngularVelocity(m_bodyId, aVelocity);
}

float RigidBody::GetAngularVelocity() const
{
	return Engine::Get().Physics().GetAngularVelocity(m_bodyId);
}

void RigidBody::SetFriction(const float aFriction) const
{
	Engine::Get().Physics().SetFriction(m_bodyId, aFriction);
}

void RigidBody::SetFiltering(const signed short aIndex, const unsigned short aCategory, const unsigned short aMask) const
{
	Engine::Get().Physics().SetFiltering(m_bodyId, aIndex, aCategory, aMask);
}

void RigidBody::SetSensor(const bool aSensor) const
{
	Engine::Get().Physics().SetSensor(m_bodyId, aSensor);
}

void RigidBody::SetRestitution(const float aRestitution) const
{
	Engine::Get().Physics().SetRestitution(m_bodyId, aRestitution);
}

void RigidBody::ForceTransform(float x, float y, float angle) const
{
	Engine::Get().Physics().SetTransform(m_bodyId, x, y, angle);
}

void RigidBody::Destroy()
{
	Engine::Get().Physics().DestroyBody(m_bodyId);
}
