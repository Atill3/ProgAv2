#include <Parallax.h>
#include <Engine.h>
#include <tinyxml.h>

void bart::Parallax::Load(const std::string& filename)
{
	mTextureId = Engine::Get().Graphics().LoadTexture(filename);
}

void Parallax::Start()
{
	int w, h;
	Engine::Get().Graphics().GetWindowSize(&w, &h);
	mDstRectA.Set(0.0f, 0.0f, static_cast<float>(w), static_cast<float>(h));
	mDstRectB.Set(mDstRectA);
	mDstRectB.x = mDstRectA.x + mDstRectA.width;
    m_ScreenWidth = static_cast<float>(w);
}

void bart::Parallax::Render()
{
    Engine::Get().Graphics().EnableViewport(false);
	Engine::Get().Graphics().DrawTexture(mTextureId, mDstRectA, m_Color);
	Engine::Get().Graphics().DrawTexture(mTextureId, mDstRectB, m_Color);
    Engine::Get().Graphics().EnableViewport(true);
}

void bart::Parallax::Scroll(const float speed)
{
    mDstRectA.x += speed;
    mDstRectB.x += speed;

    if (speed > 0)
    {
        if (mDstRectA.x > m_ScreenWidth)
        {
	        const float tRest = m_ScreenWidth - mDstRectA.x;
            mDstRectA.x = 0 - mDstRectA.width - tRest;
        }

        if (mDstRectB.x > m_ScreenWidth)
        {
	        const float tRest = m_ScreenWidth - mDstRectB.x;
            mDstRectB.x = 0 - mDstRectB.width - tRest;
        }
    }
    else
    {
        if ((mDstRectA.x + mDstRectA.width) < 0)
        {
	        const float tRest = (mDstRectA.x + mDstRectA.width);
            mDstRectA.x = m_ScreenWidth + tRest;
        }

        if ((mDstRectB.x + mDstRectB.width) < 0)
        {
	        const float tRest = (mDstRectB.x + mDstRectB.width);
            mDstRectB.x = m_ScreenWidth + tRest;
        }
    }
}

void Parallax::SetColor(const unsigned char r, const unsigned char g, const unsigned char b, const unsigned char a)
{
	m_Color.Set(r, g, b, a);
}

void Parallax::SetColor(const Color& color)
{
	m_Color.Set(color);
}

void bart::ParallaxFactory::Create(Entity* entity, XMLElement* element, Properties& props)
{
	Parallax* parallax = entity->AddComponent<Parallax>();
	const string filename = element->Attribute("filename");
	parallax->Load(filename);

	const Color color = props.GetColor("color");
	parallax->SetColor(color);
}
