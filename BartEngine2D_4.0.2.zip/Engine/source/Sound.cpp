#include <Sound.h>
#include <Engine.h>
#include <tinyxml.h>

void Sound::Load(const string& filename)
{
	m_SoundId = Engine::Get().Audio().LoadSound(filename);
}

void Sound::Play() const
{
	Engine::Get().Audio().PlaySound(m_SoundId, 0);
}

void Sound::SetVolume(const int volume) const
{
	Engine::Get().Audio().SetVolume(m_SoundId, volume);
}

void SoundFactory::Create(Entity* entity, XMLElement* element, Properties& props)
{
	Sound* sfx = entity->AddComponent<Sound>();
	const string filename = element->Attribute("filename");
	sfx->Load(filename);

	if (props.HasProperty("volume"))
	{
		const int volume = props.GetInt("volume");
		sfx->SetVolume(volume);
	}

	const bool play = props.GetBool("play");
	if (play)
	{
		sfx->Play();
	}
}
