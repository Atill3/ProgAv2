#include <Atlas.h>
#include <tinyxml.h>
#include <Engine.h>

void bart::Atlas::AddFrame(const string& name, const int x, const int y, const int w, const int h)
{
	m_Frames.emplace(name, RectI{x, y, w, h});

	if(m_Frames.size() == 1)
	{
		SetFrame(name);
	}
}

void bart::Atlas::SetFrame(const string& name)
{
	m_Source.Set(m_Frames[name]);
}

void bart::Atlas::LoadFromFile(const string& filename)
{
	XMLDocument document;
	if (document.LoadFile(filename.c_str()) == XML_SUCCESS)
	{
		XMLNode* node = document.FirstChild();
		if (node)
		{
			XMLNode* child = node->FirstChild();
			while (child)
			{
				string value = child->Value();
				if (value.compare("texture") == 0)
				{
					XMLElement* texElem = child->ToElement();
					const char* texture = texElem->Attribute("filename");
					Load(texture);
				}
				else if (value.compare("frames") == 0)
				{
					XMLNode* clip = child->FirstChild();
					while (clip)
					{
						XMLElement* clipElem = clip->ToElement();
						const char* name = clipElem->Attribute("id");
						const int x = clipElem->IntAttribute("x");
						const int y = clipElem->IntAttribute("y");
						const int w = clipElem->IntAttribute("w");
						const int h = clipElem->IntAttribute("h");
						AddFrame(name, x, y, w, h);
						clip = clip->NextSibling();
					}
				}

				child = child->NextSibling();
			}
		}
	}
	else
	{
		Engine::Get().Logger().LogError(string(document.ErrorStr()));
	}
}

void bart::AtlasFactory::Create(Entity* entity, XMLElement* element, Properties& props)
{
	Atlas* atlas = entity->AddComponent<Atlas>();
	const string filename = element->Attribute("filename");
	atlas->LoadFromFile(filename);

	const bool play = props.GetBool("play");
	const string frame = props.GetString("frame");

	if (!frame.empty())
	{
		atlas->SetFrame(frame);
	}

	const Color color = props.GetColor("color");
	atlas->SetColor(color);
}
