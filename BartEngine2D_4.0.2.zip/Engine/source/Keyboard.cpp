#include <Keyboard.h>
#include <Transform.h>
#include <Entity.h>
#include <Engine.h>
#include <tinyxml.h>

void Keyboard::Start()
{
	m_Transform = m_Owner->GetComponent<Transform>();
	if (!m_Transform)
	{
		Engine::Get().Logger().Log("Transform Component not found");
	}
}

void Keyboard::Update(float deltaTime)
{
	IInput& input = Engine::Get().Input();
	float x = 0.0f;
	float y = 0.0f;

	if (input.IsKeyDown(KEY_UP) || input.IsKeyDown(KEY_W))
	{
		y = -m_Speed;
	}
	else if (input.IsKeyDown(KEY_DOWN) || input.IsKeyDown(KEY_S))
	{
		y = m_Speed;
	}

	if (input.IsKeyDown(KEY_LEFT) || input.IsKeyDown(KEY_A))
	{
		x = -m_Speed;
	}
	else if (input.IsKeyDown(KEY_RIGHT) || input.IsKeyDown(KEY_D))
	{
		x = m_Speed;
	}

	m_Transform->Translate(x * deltaTime, y * deltaTime);
}

void Keyboard::SetSpeed(const float speed)
{
	m_Speed = speed;
}

void KeyboardFactory::Create(Entity* entity, XMLElement* element, Properties& props)
{
	Keyboard* keyboard = entity->AddComponent<Keyboard>();
	const float speed = props.GetFloat("speed");
	keyboard->SetSpeed(speed);
}
