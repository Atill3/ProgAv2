#include <Text.h>
#include <Engine.h>
#include <Transform.h>
#include <tinyxml.h>

void bart::Text::Load(const std::string& filename, const int size)
{
	m_FontId = Engine::Get().Graphics().LoadFont(filename, size);
}

void bart::Text::Start()
{
	m_Transform = m_Owner->GetComponent<Transform>();
	assert(m_Transform);
}

void bart::Text::Render()
{
	Engine::Get().Graphics().DrawString(m_Text, m_FontId, m_Transform->m_Destination.x, m_Transform->m_Destination.y, m_Color);
}

void bart::Text::SetText(const std::string& text)
{
	m_Text = text;
}

void bart::Text::SetColor(const Color& color)
{
	m_Color.Set(color);
}

void TextFactory::Create(Entity* entity, XMLElement* element, Properties& props)
{
	Text* text = entity->AddComponent<Text>();

	const std::string fontname = element->Attribute("fontname");
	const int fontsize = element->IntAttribute("fontsize");
	text->Load(fontname, fontsize);

	if (props.HasProperty("text"))
	{
		const std::string textStr = props.GetString("text");
		text->SetText(textStr);
	}
	else
	{
		text->SetText("Text");
	}

	const Color color = props.GetColor("color");
	text->SetColor(color);
}
