#include <Camera.h>
#include <Engine.h>
#include <Entity.h>

void Camera::Start()
{
	m_Transform = m_Owner->GetComponent<Transform>();
	assert(m_Transform);

	m_Graphics = &Engine::Get().Graphics();
	assert(m_Graphics);

	m_Maths = &Engine::Get().Maths();
	assert(m_Maths);

	if (m_FollowTarget)
	{
		GetTargetInfo();
	}
}

void Camera::Update(float deltaTime)
{
	if (m_FollowTarget)
	{
		const float cameraHalfWidth = m_Transform->m_Destination.width / 2.0f;
		const float cameraHalfHeight = m_Transform->m_Destination.height / 2.0f;
		const float targetHalfWidth = m_Target->m_Destination.width / 2.0f;
		const float targetHalfHeight = m_Target->m_Destination.height / 2.0f;
		m_Transform->m_Destination.x = m_Target->m_Destination.x - cameraHalfWidth + targetHalfWidth;
		m_Transform->m_Destination.y = m_Target->m_Destination.y - cameraHalfHeight + targetHalfHeight;
	}

	if (m_ConstrainCamera)
	{
		m_ClampBottomX = m_Bounds.x + m_Bounds.width - m_Transform->m_Destination.width;
		m_ClampBottomY = m_Bounds.y + m_Bounds.height - m_Transform->m_Destination.height;
		m_Transform->m_Destination.x = m_Maths->Clamp(m_Transform->m_Destination.x, m_Bounds.x, m_ClampBottomX);
		m_Transform->m_Destination.y = m_Maths->Clamp(m_Transform->m_Destination.y, m_Bounds.y, m_ClampBottomY);
	}

	m_Graphics->SetViewport(m_Transform->m_Destination);
}

void Camera::SetConstrain(const bool constrain)
{
	m_ConstrainCamera = constrain;
}

void Camera::SetBounds(const float x, const float y, const float width, const float height)
{
	m_Bounds.Set(x, y, width, height);
}

void Camera::SetTarget(const string& target, const bool findEntity)
{
	m_FollowTarget = true;
	m_TargetName = target;

	if (findEntity)
	{
		GetTargetInfo();
	}
}

void Camera::GetTargetInfo()
{
	Entity* targetEntity = Engine::Get().Scene().FindEntity(m_TargetName);
	if (targetEntity)
	{
		m_Target = targetEntity->GetComponent<Transform>();
		assert(m_Target);
	}
}

void CameraFactory::Create(Entity* entity, XMLElement* element, Properties& props)
{
	Camera* camera = entity->AddComponent<Camera>();

	if (props.HasProperty("constrain"))
	{
		const bool constrain = props.GetBool("constrain");
		camera->SetConstrain(constrain);

		const float x = props.GetFloat("x");
		const float y = props.GetFloat("y");
		const float w = props.GetFloat("width");
		const float h = props.GetFloat("height");
		camera->SetBounds(x, y, w, h);
	}

	if (props.HasProperty("target"))
	{
		const string target = props.GetString("target");
		camera->SetTarget(target, false);
	}
}
