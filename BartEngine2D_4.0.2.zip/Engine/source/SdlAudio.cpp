#include <Bart2d.h>
#include <SdlAudio.h>
#include <SDL_mixer.h>
#include <Engine.h>

bool SdlAudio::Initialize()
{
	if (Mix_OpenAudio(22050, AUDIO_S16, 2, 2048) != 0)
	{
		const char* errorMessage = Mix_GetError();
		const string errorString(errorMessage);

		Engine::Get().Logger().LogError("Error with SDL audio: " + errorString);
		return false;
	}

	return true;
}

void SdlAudio::Destroy()
{
	Mix_CloseAudio();
}

size_t SdlAudio::LoadMusic(const string& filename)
{
	const size_t musicId = std::hash<std::string>()(filename);
	if (m_MusicCache.count(musicId) > 0)
	{
		return musicId;
	}

	_Mix_Music* music = Mix_LoadMUS(filename.c_str());
	if (music)
	{
		m_MusicCache.emplace(musicId, music);
		return musicId;
	}

	const char* errorMessage = Mix_GetError();
	const string errorString(errorMessage);
	Engine::Get().Logger().LogError("Cannot load music: " + filename);
	Engine::Get().Logger().LogError(errorMessage);
	return 0;
}

size_t SdlAudio::LoadSound(const string& filename)
{
	const size_t soundId = std::hash<std::string>()(filename);
	if (m_SoundCache.count(soundId) > 0)
	{
		return soundId;
	}

	Mix_Chunk* sound = Mix_LoadWAV(filename.c_str());
	if (sound)
	{
		m_SoundCache.emplace(soundId, sound);
		return soundId;
	}

	const char* errorMessage = Mix_GetError();
	const string errorString(errorMessage);
	Engine::Get().Logger().LogError("Cannot load sound: " + filename);
	Engine::Get().Logger().LogError(errorMessage);
	return 0;
}

void SdlAudio::PlayMusic(const size_t id, const int loop)
{
	_Mix_Music* ptr = m_MusicCache[id];
	Mix_PlayMusic(ptr, loop);
}

void SdlAudio::PlaySound(const size_t id, const int loop)
{
	Mix_Chunk* ptr = m_SoundCache[id];
	Mix_PlayChannel(-1, ptr, loop);
}

void SdlAudio::PauseMusic()
{
	Mix_PauseMusic();
}

void SdlAudio::StopMusic()
{
	Mix_HaltMusic();
}

void SdlAudio::ResumeMusic()
{
	Mix_ResumeMusic();
}

void SdlAudio::SetVolume(const int volume)
{
	Mix_VolumeMusic(volume);
}

void SdlAudio::SetVolume(const size_t soundId, const int volume)
{
	Mix_Chunk* ptr = m_SoundCache[soundId];
	Mix_VolumeChunk(ptr, volume);
}
