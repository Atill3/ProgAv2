#include <Background.h>
#include <Engine.h>
#include <tinyxml.h>

void bart::Background::Load(const string& filename)
{
	m_TextureId = Engine::Get().Graphics().LoadTexture(filename);
}

void bart::Background::Render()
{
	Engine::Get().Graphics().DrawTexture(m_TextureId, m_Color);
}

void bart::Background::SetColor(const unsigned char r, const unsigned char g, const unsigned char b, const unsigned char a)
{
	m_Color.Set(r, g, b, a);
}

void bart::Background::SetColor(const Color& color)
{
	m_Color.Set(color);
}

void bart::BackgroundFactory::Create(Entity* entity, XMLElement* element, Properties& props)
{
	Background* background = entity->AddComponent<Background>();
	const string filename = element->Attribute("filename");
	background->Load(filename);

	const Color color = props.GetColor("color");
	background->SetColor(color);
}
