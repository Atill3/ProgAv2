#include <Entity.h>
#include <tinyxml.h>
#include <Engine.h>

void Entity::Update(const float deltaTime)
{
	if (m_IsActive)
	{
		for (Component* component : m_Components)
		{
			component->Update(deltaTime);
		}
	}
}

void Entity::Render()
{
	if (m_IsActive)
	{
		for (Component* component : m_Components)
		{
			component->Render();
		}
	}
}

void Entity::Destroy()
{
	m_IsActive = false;
	for (Component* component : m_Components)
	{
		component->Destroy();
		delete component;
	}
	m_Components.clear();
}

void Entity::Start()
{
	if (m_IsActive)
	{
		for (Component* component : m_Components)
		{
			component->Start();
		}
	}
}

void Entity::SetActive(const bool active)
{
	if (m_IsActive != active)
	{
		m_IsActive = active;
		if (m_IsActive)
		{
			for (Component* component : m_Components)
			{
				component->OnEnable();
			}
		}
		else
		{
			for (Component* component : m_Components)
			{
				component->OnDisable();
			}
		}
	}
}

void Entity::SetLayer(const string& layer)
{
	m_LayerName = layer;
}

void Entity::LoadFromFile(const string& filename, Properties& props)
{
	XMLDocument tDocument;
	if (tDocument.LoadFile(filename.c_str()) == XML_SUCCESS)
	{
		XMLNode* node = tDocument.FirstChild();
		if (node)
		{
			node = node->FirstChild();
			while (node != nullptr)
			{
				std::string nodeName = node->Value();
				Engine::Get().Scene().AddComponentTo(this, nodeName, node, props);
				node = node->NextSibling();
			}
		}
	}
	else
	{
		Engine::Get().Logger().LogError(string(tDocument.ErrorStr()));
	}
}

void Entity::OnCollisionEnter(Entity* entity, const vector<pair<float, float>>& contact, float normalX, float normalY)
{
	if (m_IsActive)
	{
		for (Component* component : m_Components)
		{
			component->OnCollisionEnter(entity, contact, normalX, normalY);
		}
	}
}

void Entity::OnCollisionExit(Entity* entity)
{
	if (m_IsActive)
	{
		for (Component* component : m_Components)
		{
			component->OnCollisionExit(entity);
		}
	}
}
