#include <Bart2d.h>
#include <SceneService.h>
#include <tinyxml.h>
#include <Engine.h>
#include <Color.h>
#include <EngineComponents.h>

bool SceneService::Initialize()
{
	RegisterFactory(ANIMATION_COMPONENT, new AnimationFactory());
	RegisterFactory(ATLAS_COMPONENT, new AtlasFactory());
	RegisterFactory(KEYBOARD_COMPONENT, new KeyboardFactory());
	RegisterFactory(MUSIC_COMPONENT, new MusicFactory());
	RegisterFactory(RIGIDBODY_COMPONENT, new RigidBodyFactory());
	RegisterFactory(SOUND_COMPONENT, new SoundFactory());
	RegisterFactory(SPRITE_COMPONENT, new SpriteFactory());
	RegisterFactory(SQUARE_COMPONENT, new SquareFactory());
	RegisterFactory(TEXT_COMPONENT, new TextFactory());
	RegisterFactory(CAMERA_COMPONENT, new CameraFactory());
	RegisterFactory(BACKGROUND_COMPONENT, new BackgroundFactory());
	RegisterFactory(PARALLAX_COMPONENT, new ParallaxFactory());

	return true;
}

void SceneService::Destroy()
{
	typedef map<string, ComponentFactory*>::iterator Iterator;
	for (Iterator itr = m_Factories.begin(); itr != m_Factories.end(); ++itr)
	{
		delete itr->second;
	}

	m_Factories.clear();
	Unload();
}

void SceneService::Load(const string& name)
{
	if (m_SceneMap.count(name) > 0)
	{
		const string targetScene = name;
		if (!m_CurrentScene.empty())
		{
			Unload();
		}

		m_CurrentScene = targetScene;
		const string path = m_SceneMap[targetScene];
		m_TileMap.Load(path);

		const Color bgColor = m_TileMap.GetBackgroundColor();
		Engine::Get().Graphics().SetClearColor(bgColor);
	}
	else
	{
		Engine::Get().Logger().LogError("Cannot find scene " + name);
	}
}

void SceneService::Unload()
{
	m_CurrentScene.clear();

	for (Entity* entity : m_StartingEntities)
	{
		delete entity;
	}

	m_StartingEntities.clear();

	for (Entity* entity : m_RunningEntities)
	{
		entity->Destroy();
		delete entity;
	}

	m_RunningEntities.clear();
	m_EntityByNames.clear();
	m_TileMap.Clean();
	m_EntityByLayer.clear();
}

void SceneService::Update(const float deltaTime)
{
	for (Entity* entity : m_RunningEntities)
	{
		entity->Update(deltaTime);
	}

	if (m_StartingEntities.size() > 0)
	{
		vector<Entity*> entities = m_StartingEntities;
		m_StartingEntities.clear();

		for (Entity* entity : entities)
		{
			m_RunningEntities.emplace_back(entity);
			string layer = entity->GetLayer();
			if (m_EntityByLayer.count(layer) > 0)
			{
				m_EntityByLayer[layer].emplace_back(entity);
			}

			entity->Start();
		}
	}

	if (m_RemoveEntities.size() > 0)
	{
		RemoveEntities();
	}
}

void SceneService::Render()
{
	m_TileMap.Draw();
}

Entity* SceneService::AddEntity(const string& name, const string& layer)
{
	Entity* entity = new Entity();
	entity->SetLayer(layer);
	entity->SetName(name);
	m_StartingEntities.emplace_back(entity);
	m_EntityByNames[name] = entity;
	return entity;
}

Entity* SceneService::FindEntity(const string& name)
{
	if (m_EntityByNames.count(name) > 0)
	{
		return m_EntityByNames[name];
	}

	return nullptr;
}

Entity* SceneService::AddEntityFromPrefab(const string& name,
                                          const string& prefab,
                                          const string& layer,
                                          const RectF& transform,
                                          float angle,
                                          Properties& props)
{
	if (m_PrefabRegistry.count(prefab) > 0)
	{
		const string prefabPath = m_PrefabRegistry[prefab];
		Entity* entity = new Entity();
		entity->SetLayer(layer);
		entity->SetName(name);
		m_StartingEntities.emplace_back(entity);
		m_EntityByNames[name] = entity;
		Transform* component = entity->AddComponent<Transform>();
		component->Set(transform);
		entity->LoadFromFile(prefabPath, props);
		return entity;
	}

	Engine::Get().Logger().LogError("Cannot find prefab " + prefab + " on layer " + layer + " for entity " + name);
	return nullptr;
}

void SceneService::RemoveEntity(const string& name)
{
	Entity* ptr = FindEntity(name);
	RemoveEntity(ptr);
}

void SceneService::RemoveEntity(Entity* entity)
{
	m_RemoveEntities.emplace_back(entity);
}

void SceneService::RegisterScenes(XMLNode* node)
{
	if (node)
	{
		XMLNode* child = node->FirstChild();
		while (child)
		{
			XMLElement* childElement = child->ToElement();
			string sceneName = childElement->Attribute("name");
			string scenePath = childElement->Attribute("filename");
			if (!sceneName.empty() && !scenePath.empty())
			{
				m_SceneMap.emplace(sceneName, scenePath);
				if (m_CurrentScene.empty())
				{
					Load(sceneName);
				}
			}

			child = child->NextSibling();
		}
	}
}

void SceneService::RenderLayer(const string& layer)
{
	for (Entity* entity : m_EntityByLayer[layer])
	{
		entity->Render();
	}
}

void SceneService::AddLayer(const string& layer)
{
	if (m_EntityByLayer.count(layer) == 0)
	{
		m_EntityByLayer.emplace(layer, vector<Entity*>());
	}
}

void SceneService::RegisterPrefabs(XMLNode* node)
{
	if (node)
	{
		XMLNode* child = node->FirstChild();
		while (child)
		{
			XMLElement* childElement = child->ToElement();
			string name = childElement->Attribute("name");
			string path = childElement->Attribute("filename");
			m_PrefabRegistry.emplace(name, path);
			child = child->NextSibling();
		}
	}
}

void SceneService::RegisterFactory(const string& name, ComponentFactory* factory)
{
	if (!m_Factories.count(name))
	{
		m_Factories[name] = factory;
	}
}

void SceneService::AddComponentTo(Entity* entity, const string& factory, XMLNode* node, Properties& props)
{
	if (m_Factories.count(factory) > 0)
	{
		m_Factories[factory]->Create(entity, node->ToElement(), props);
	}
	else
	{
		Engine::Get().Logger().LogError("No factory found for component " + factory);
	}
}

void SceneService::Reload()
{
	if (!m_CurrentScene.empty())
	{
		const string savedSceneName = m_CurrentScene;
		Unload();
		Load(savedSceneName);
	}
}

TileMap* SceneService::GetMap()
{
	return &m_TileMap;
}

void SceneService::RemoveEntities()
{
	for (Entity* entity : m_RemoveEntities)
	{
		string name = entity->GetName();
		string layer = entity->GetLayer();

		m_EntityByNames.erase(name);

		vector<Entity*>::iterator itr;
		for (itr = m_RunningEntities.begin(); itr != m_RunningEntities.end(); ++itr)
		{
			if (*itr == entity)
			{
				m_RunningEntities.erase(itr);
				break;
			}
		}

		for (itr = m_StartingEntities.begin(); itr != m_StartingEntities.end(); ++itr)
		{
			if (*itr == entity)
			{
				m_StartingEntities.erase(itr);
				break;
			}
		}

		for (itr = m_EntityByLayer[layer].begin(); itr != m_EntityByLayer[layer].end(); ++itr)
		{
			if (*itr == entity)
			{
				m_EntityByLayer[layer].erase(itr);
				break;
			}
		}

		entity->Destroy();
		delete entity;
	}

	m_RemoveEntities.clear();
}
