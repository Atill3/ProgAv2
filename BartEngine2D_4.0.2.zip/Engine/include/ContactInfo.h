#pragma once

#include <vector>
#include <EContactType.h>
#include <Entity.h>

namespace bart
{
	struct ContactInfo
	{
		EContactType ContactType;
		Entity* EntityA;
		Entity* EntityB;
		std::vector<std::pair<float, float>> ContactPoints;
		float NormalX;
		float NormalY;
	};
}
