#pragma once

namespace bart
{
	enum EWindowState
	{
		FULLSCREEN = 0,
		BORDERLESS = 1,
		WINDOWED = 2,

		COUNT = 3
	};
}
