#pragma once

namespace bart
{
	enum EContactType
	{
		BEGIN_CONTACT,
		END_CONTACT
	};
}
