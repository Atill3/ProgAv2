#pragma once
#pragma push_macro("new")
#undef new
#include <tinyxml2.h>
#pragma pop_macro("new")