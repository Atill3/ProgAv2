#pragma once

#include <Component.h>
#include <Color.h>
#include <string>
#include <ComponentFactory.h>

namespace bart
{
	class Transform;

	class Text final : public Component
	{
	public:
		virtual ~Text() = default;

		void Load(const std::string& filename, int size);
		void Start() override;
		void Render() override;
		void SetText(const std::string& text);
		void SetColor(const Color& color);

	private:
		std::string m_Text;
		size_t m_FontId = 0;
		Color m_Color {Color::Black};
		Transform* m_Transform = nullptr;
	};

	class TextFactory final : public ComponentFactory
	{
	public:
		virtual ~TextFactory() = default;
		void Create(Entity* entity, XMLElement* element, Properties& props) override;
	};
}
