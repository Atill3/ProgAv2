#pragma once

#include <Component.h>
#include <ComponentFactory.h>
#include <Rect.h>
#include <Flip.h>

namespace bart
{
	class Parallax final : public Component
	{
	public:
		virtual ~Parallax() = default;
		void Load(const std::string& filename);
		void Start() override;
		void Render() override;
		void Scroll(float speed);
		void SetColor(unsigned char r, unsigned char g, unsigned char b, unsigned char a);
		void SetColor(const Color& color);

	private:
		size_t mTextureId = 0;
		Color m_Color{ 255, 255, 255, 255 };
		RectI mSrcRectA{};
		RectI mSrcRectB{};
		RectF mDstRectA{};
		RectF mDstRectB{};
		Flip m_Flip;
		float m_ScreenWidth = 0.0f;
	};

	class ParallaxFactory final : public ComponentFactory
	{
	public:
		virtual ~ParallaxFactory() = default;
		void Create(Entity* entity, XMLElement* element, Properties& props) override;
	};
}
