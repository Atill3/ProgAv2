#pragma once

#include <Layer.h>
#include <TileSet.h>
#include <vector>
#include <TileInfo.h>
#include <Rect.h>

namespace bart
{
	class TileLayer final : public Layer
	{
	public:
		TileLayer() = default;
		explicit TileLayer(Tileset* tileset, int width, int height);
		virtual ~TileLayer() = default;
		void ParseTileData(const char* data);
		bool Load(XMLNode* node) override;
		void Clean() override;
		void Draw() override;
		int GetValueAt(const int x, const int y) const { return m_LayerData[y][x]->Index; }
		void SetValueAt(const int x, const int y, const int value) { m_LayerData[y][x]->Index = value; }
		int IsColliding(const RectF& colliderRect, int* x, int* y);
		int IsColliding(const RectF& colliderRect);

	private:
		float Clamp(float value, float min, float max) const;

		typedef std::vector<std::vector<TileInfo*>> TTileMap;
		TTileMap m_LayerData;
		int m_Width{0};
		int m_Height{0};
		int m_TileWidth{0};
		int m_TileHeight{0};
		Tileset* m_TilesetPtr{nullptr};
	};
}
