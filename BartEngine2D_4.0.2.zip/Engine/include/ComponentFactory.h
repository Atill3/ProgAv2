#pragma once

#include <Properties.h>

namespace tinyxml2
{
	class XMLElement;
}

using namespace tinyxml2;

namespace bart
{
	class Entity;

	class ComponentFactory
	{
	public:
		virtual ~ComponentFactory() = default;
		virtual void Create(Entity* entity, XMLElement* element, Properties& props) = 0;
	};
}
