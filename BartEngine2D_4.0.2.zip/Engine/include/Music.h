#pragma once

#include <Component.h>
#include <string>
#include "ComponentFactory.h"

using namespace std;

namespace bart
{
	class Music final : public Component
	{
	public:
		virtual ~Music() = default;
		void Load(const string& filename);
		void Play();
		void Play(int loop);
		void Pause() const;
		void Stop();
		void Resume() const;
		void SetVolume(int volume) const;
		void OnEnable() override;
		void OnDisable() override;
		void Destroy() override;

	private:
		size_t m_MusicId = 0;
		bool m_Playing = false;
	};

	class MusicFactory final : public ComponentFactory
	{
	public:
		void Create(Entity* entity, XMLElement* element, Properties& props) override;
	};
}
