#pragma once

#include <IAudio.h>
#include <string>
#include <map>

using namespace std;

struct Mix_Chunk;
struct _Mix_Music;

namespace bart
{
	class SdlAudio final : public IAudio
	{
	public:
		virtual ~SdlAudio() = default;

		bool Initialize() override;
		void Destroy() override;
		size_t LoadMusic(const string& filename) override;
		size_t LoadSound(const string& filename) override;
		void PlayMusic(size_t id, int loop) override;
		void PlaySound(size_t id, int loop) override;
		void PauseMusic() override;
		void StopMusic() override;
		void ResumeMusic() override;
		void SetVolume(int volume) override;
		void SetVolume(size_t soundId, int volume) override;

	private:
		typedef map<size_t, Mix_Chunk*> TChunkMap;
		typedef map<size_t, _Mix_Music*> TMusicMap;

		TChunkMap m_SoundCache;
		TMusicMap m_MusicCache;
	};
}
