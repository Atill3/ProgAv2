#pragma once

#include <IService.h>
#include <Rect.h>

namespace bart
{
	class IMaths : public IService
	{
	public:
		virtual ~IMaths() = default;
		virtual int Random() = 0;

		template <typename T>
		bool IsColliding(const Rect<T>& rectA, const Rect<T>& rectB)
		{
			return rectA.x < (rectB.x + rectB.width) && (rectA.x + rectA.width) > rectB.x &&
				(rectA.y + rectA.h) >= rectB.y && rectA.y <= (rectB.y + rectB.h);
		}

		template <typename T>
		bool IsColliding(const Rect<T>& rect, T x, T y)
		{
			return rect.x < x && (rect.x + rect.width) > x && (rect.y + rect.height) >= y && rect.y <= y;
		}

		template <typename T>
		T Range(T min, T max)
		{
			return min + static_cast<T>(Random()) / (static_cast<T>(RAND_MAX) / (max - min));
		}

		template <class T>
		T Clamp(const T aValue, const T aMin, const T aMax)
		{
			T tValue = aValue;

			if (tValue < aMin)
			{
				tValue = aMin;
			}
			else if (tValue > aMax)
			{
				tValue = aMax;
			}

			return tValue;
		}

		template <class T>
		T Min(const T aValA, const T aValB)
		{
			if (aValB < aValA)
			{
				return aValB;
			}

			return aValA;
		}

		template <class T>
		T Max(const T aValA, const T aValB)
		{
			if (aValB > aValA)
			{
				return aValB;
			}

			return aValA;
		}

		const float PI = 4.0f * atanf(1.0f);
		const float TwoPI = 2.0f * PI;
		const float PIOverTwo = 0.5f * PI;
		const float PIOverFour = 0.25f * PI;
		const float TO_RADIANS = PI / 180.0f;
		const float TO_DEGREES = 180.0f / PI;
	};
}
