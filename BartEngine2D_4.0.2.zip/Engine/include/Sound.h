#pragma once

#include <Component.h>
#include <string>
#include "ComponentFactory.h"

using namespace std;

namespace bart
{
	class Sound final : public Component
	{
	public:
		virtual ~Sound() = default;
		void Load(const string& filename);
		void Play() const;
		void SetVolume(int volume) const;

	private:
		size_t m_SoundId = 0;
	};

	class SoundFactory final : public ComponentFactory
	{
	public:
		void Create(Entity* entity, XMLElement* element, Properties& props) override;
	};
}
