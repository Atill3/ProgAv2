#pragma once

namespace bart
{
	struct TileInfo
	{
		int Index{0};
		bool HorizontalFlip{false};
		bool VerticalFlip{false};
		bool DiagonalFlip{false};
	};
}
