#pragma once

#include <Component.h>
#include <ComponentFactory.h>
#include <Flip.h>

namespace bart
{
	class Background final : public Component
	{
	public:
		virtual ~Background() = default;
		void Load(const string& filename);
		void Render() override;
		void SetColor(unsigned char r, unsigned char g, unsigned char b, unsigned char a);
		void SetColor(const Color& color);

	protected:
		size_t m_TextureId = 0;
		Color m_Color{255, 255, 255, 255};
		Flip m_Flip;
	};

	class BackgroundFactory final : public ComponentFactory
	{
	public:
		virtual ~BackgroundFactory() = default;
		void Create(Entity* entity, XMLElement* element, Properties& props) override;
	};
}
