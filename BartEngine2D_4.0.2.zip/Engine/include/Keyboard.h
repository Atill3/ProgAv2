#pragma once

#include <Component.h>
#include <ComponentFactory.h>

namespace bart
{
	class Transform;

	class Keyboard final : public Component
	{
	public:
		virtual ~Keyboard() = default;

		void Start() override;
		void Update(float deltaTime) override;
		void SetSpeed(float speed);

	private:
		float m_Speed = 5.0f;
		Transform* m_Transform = nullptr;
	};

	class KeyboardFactory final : public ComponentFactory
	{
	public:
		void Create(Entity* entity, XMLElement* element, Properties& props) override;
	};
}
