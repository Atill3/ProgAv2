#pragma once

#include <Entity.h>

namespace bart
{
	struct RayCastInfo
	{
		Entity* Entity;
		float NormalX;
		float NormalY;
		float PointX;
		float PointY;
	};
}
