#pragma once

#include <Component.h>
#include <PhysicMaterial.h>
#include <Transform.h>
#include <EBodyType.h>
#include <EShapeType.h>
#include <ComponentFactory.h>

namespace bart
{
	class Entity;

	class RigidBody final : public Component
	{
	public:
		RigidBody() = default;
		virtual ~RigidBody() = default;

		void Set(EBodyType aBody, EShapeType aShape);
		void Update(float aDelta) override;
		void ApplyImpulse(float aX, float aY, bool aWorld) const;
		void ApplyForce(float aX, float aY, bool aWorld) const;
		void ApplyAngularImpulse(float aImpulse) const;
		void ApplyTorque(float aTorque) const;
		void SetGravityScale(float aScale) const;
		float GetMass() const;
		void SetMass(float aMass) const;
		void FixRotation(bool aFixed) const;
		void GetVelocity(float* aX, float* aY) const;
		void SetVelocity(float aX, float aY) const;
		void SetAngularVelocity(float aVelocity) const;
		float GetAngularVelocity() const;
		void SetFriction(float aFriction) const;
		void SetFiltering(signed short aIndex, unsigned short aCategory, unsigned short aMask) const;
		void SetSensor(bool aSensor) const;
		void SetRestitution(float aRestitution) const;
		void Destroy() override;
		void ForceTransform(float x, float y, float angle) const;
		void Start() override;

	protected:
		size_t m_bodyId{0};
		EBodyType m_Body{DYNAMIC_BODY};
		EShapeType m_Shape{RECTANGLE_SHAPE};
		Transform* m_Transform{nullptr};
		PhysicMaterial m_Material;
	};

	class RigidBodyFactory final : public ComponentFactory
	{
	public:
		void Create(Entity* entity, XMLElement* element, Properties& props) override;
	};
}
