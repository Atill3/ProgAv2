#pragma once

#include <IService.h>
#include <Entity.h>
#include <string>
#include <Properties.h>
#include <Rect.h>
#include <ComponentFactory.h>
#include "TileLayer.h"
#include "TileMap.h"

namespace tinyxml2
{
	class XMLNode;
}

using namespace tinyxml2;
using namespace bart;

namespace bart
{
	class IScene : public IService
	{
	public:
		virtual ~IScene() = default;
		virtual void Load(const string& name) = 0;
		virtual void Unload() = 0;
		virtual void Update(float deltaTime) = 0;
		virtual void Render() = 0;

		virtual Entity* AddEntity(const string& name, const string& layer) = 0;
		virtual Entity* AddEntityFromPrefab(const string& name, const string& prefab, const string& layer, const RectF& transform, float angle, Properties& props) = 0;
		virtual Entity* FindEntity(const string& name) = 0;
		virtual void RemoveEntity(const string& name) = 0;
		virtual void RemoveEntity(Entity* entity) = 0;

		virtual void RegisterScenes(XMLNode* node) = 0;
		virtual void RenderLayer(const string& layer) = 0;
		virtual void AddLayer(const string& layer) = 0;
		virtual void RegisterPrefabs(XMLNode* node) = 0;
		virtual void RegisterFactory(const string& name, ComponentFactory* factory) = 0;
		virtual void AddComponentTo(Entity* entity, const string& factory, XMLNode* node, Properties& props) = 0;
		virtual void Reload() = 0;
		virtual TileMap* GetMap() = 0;
	};
}
