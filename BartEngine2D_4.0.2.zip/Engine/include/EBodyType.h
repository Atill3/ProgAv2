#pragma once

namespace bart
{
	enum EBodyType
	{
		STATIC_BODY,
		KINEMATIC_BODY,
		DYNAMIC_BODY,
	};
}
