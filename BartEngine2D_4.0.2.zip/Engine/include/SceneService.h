#pragma once

#include <IScene.h>
#include <map>
#include <vector>
#include <string>
#include <TileMap.h>

using namespace std;

namespace bart
{
	class SceneService final : public IScene
	{
	public:
		virtual ~SceneService() = default;

		bool Initialize() override;
		void Destroy() override;
		void Load(const string& name) override;
		void Unload() override;
		void Update(float deltaTime) override;
		void Render() override;
		Entity* AddEntity(const string& name, const string& layer) override;
		Entity* FindEntity(const string& name) override;
		Entity* AddEntityFromPrefab(const string& name, const string& prefab, const string& layer, const RectF& transform, float angle, Properties& props) override;
		void RemoveEntity(const string& name) override;
		void RemoveEntity(Entity* entity) override;
		void RegisterScenes(XMLNode* node) override;
		void RenderLayer(const string& layer) override;
		void AddLayer(const string& layer) override;
		void RegisterPrefabs(XMLNode* node) override;
		void RegisterFactory(const string& name, ComponentFactory* factory) override;
		void AddComponentTo(Entity* entity, const string& factory, XMLNode* node, Properties& props) override;
		void Reload() override;
		TileMap* GetMap() override;

	private:
		void RemoveEntities();

		map<string, Entity*> m_EntityByNames;
		vector<Entity*> m_RunningEntities;
		vector<Entity*> m_StartingEntities;
		vector<Entity*> m_RemoveEntities;
		map<string, string> m_SceneMap;
		map<string, vector<Entity*>> m_EntityByLayer;
		map<string, string> m_PrefabRegistry;
		map<string, ComponentFactory*> m_Factories;
		string m_CurrentScene;
		TileMap m_TileMap;
	};
}
