#pragma once

#include <string>
#include <map>
#include <Sprite.h>
#include <Rect.h>

using namespace std;

namespace bart
{
	class Atlas final : public Sprite
	{
	public:
		virtual ~Atlas() = default;

		void AddFrame(const string& name, int x, int y, int w, int h);
		void SetFrame(const string& name);
		void LoadFromFile(const string& filename);

	private:
		typedef map<string, RectI> TFrameMap;
		TFrameMap m_Frames;
	};

	class AtlasFactory final : public ComponentFactory
	{
	public:
		void Create(Entity* entity, XMLElement* element, Properties& props) override;
	};
}
