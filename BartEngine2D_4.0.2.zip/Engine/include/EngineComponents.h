#pragma once

// ReSharper disable CppUnusedIncludeDirective
#include <Animation.h>
#include <Atlas.h>
#include <Keyboard.h>
#include <Music.h>
#include <RigidBody.h>
#include <Sound.h>
#include <Sprite.h>
#include <Square.h>
#include <Transform.h>
#include <Text.h>
#include <Camera.h>
#include <Background.h>
#include <Parallax.h>
// ReSharper restore CppUnusedIncludeDirective

constexpr auto ANIMATION_COMPONENT = "animation";
constexpr auto ATLAS_COMPONENT = "atlas";
constexpr auto KEYBOARD_COMPONENT = "keyboard";
constexpr auto MUSIC_COMPONENT = "music";
constexpr auto RIGIDBODY_COMPONENT = "rigidbody";
constexpr auto SOUND_COMPONENT = "sound";
constexpr auto SPRITE_COMPONENT = "sprite";
constexpr auto SQUARE_COMPONENT = "square";
constexpr auto TRANSFORM_COMPONENT = "transform";
constexpr auto TEXT_COMPONENT = "text";
constexpr auto CAMERA_COMPONENT = "camera";
constexpr auto BACKGROUND_COMPONENT = "background";
constexpr auto PARALLAX_COMPONENT = "parallax";
