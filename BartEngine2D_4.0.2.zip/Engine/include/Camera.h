#pragma once

#include <Component.h>
#include <ComponentFactory.h>
#include <Transform.h>
#include <IGraphics.h>
#include <IMaths.h>

namespace bart
{
	class Camera : public Component
	{
	public:
		virtual ~Camera() = default;
		void Start() override;
		void Update(float deltaTime) override;
		void SetConstrain(bool constrain);
		void SetBounds(float x, float y, float width, float height);
		void SetTarget(const string& target, bool findEntity);

	private:
		void GetTargetInfo();
		Transform* m_Transform = nullptr;
		IGraphics* m_Graphics = nullptr;
		IMaths* m_Maths = nullptr;
		bool m_ConstrainCamera = false;
		RectF m_Bounds;
		float m_ClampBottomX = 0.0f;
		float m_ClampBottomY = 0.0f;
		bool m_FollowTarget = false;
		string m_TargetName;
		Transform* m_Target = nullptr;
	};

	class CameraFactory final : public ComponentFactory
	{
	public:
		virtual ~CameraFactory() = default;
		void Create(Entity* entity, XMLElement* element, Properties& props) override;
	};
}
