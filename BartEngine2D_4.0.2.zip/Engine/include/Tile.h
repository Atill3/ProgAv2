#pragma once

#include <Rect.h>

namespace bart
{
	struct Tile
	{
		size_t Texture;
		RectI Bounds;
	};
}
