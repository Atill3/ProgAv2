#pragma once

namespace bart
{
	enum EShapeType
	{
		RECTANGLE_SHAPE,
		CIRCLE_SHAPE,
		EDGE_SHAPE,
		CHAIN_SHAPE
	};
}