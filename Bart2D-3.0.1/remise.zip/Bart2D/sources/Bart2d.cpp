#include <Bart2d.h>

/** Ce fichier existe que pour compiler (cr�er) notre Precompiled Header. Vous devez le garder. **/