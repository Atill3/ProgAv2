#pragma once

namespace bart
{
	enum ELayerDrawOrder
	{
		DO_INDEX,
		DO_TOPDOWN
	};
}
