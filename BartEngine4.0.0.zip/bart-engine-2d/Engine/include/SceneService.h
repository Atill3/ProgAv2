#pragma once

#include <IScene.h>
#include <map>
#include <vector>
#include <string>

using namespace std;

namespace bart
{
	class SceneService final : public IScene
	{
	public:
		virtual ~SceneService() = default;

		bool Initialize() override;
		void Destroy() override;
		void Load(const string& name) override;
		void Unload() override;
		void Update(float deltaTime) override;
		void Render() override;
		Entity* AddEntity(const string& name, const string& layer) override;
		Entity* FindEntity(const string& name) override;

	private:
		map<string, Entity*> m_EntityByNames;
		vector<Entity*> m_RunningEntities;
		vector<Entity*> m_StartingEntities;
		map<string, vector<Entity*>> m_EntityByLayer;
		string m_CurrentScene;
	};
}
