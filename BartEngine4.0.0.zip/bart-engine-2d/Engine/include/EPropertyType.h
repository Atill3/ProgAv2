#pragma once

namespace bart
{
	enum EPropertyType
	{
		PT_BOOL,
		PT_COLOR,
		PT_FLOAT,
		PT_INT,
		PT_STRING
	};
}
