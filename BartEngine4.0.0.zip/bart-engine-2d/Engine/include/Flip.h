#pragma once

namespace bart
{
	class Flip final
	{
	public:
		bool horizontal = false;
		bool vertical = false;
	};
}
