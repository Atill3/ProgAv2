#include <Bart2d.h>
#include <Engine.h>
#include <Config.h>
#include <cassert>

using namespace tinyxml2;

Engine& Engine::Get()
{
	static Engine instance;
	return instance;
}

bool Engine::Initialize()
{
#ifdef _DEBUG
	m_LoggingService = IService::Create<ConsoleLogger>();
#else
	m_LoggingService = IService::Create<FileLogger>();
#endif

	m_GraphicService = IService::Create<SdlGraphics>();

#ifdef _DEBUG
	const bool result = m_GraphicService->InitWindow("Test", m_Width, m_Height, WINDOWED);
#else
	const bool result = m_GraphicService->InitWindow(title, m_Width, m_Height, BORDERLESS);
#endif
	assert(result);

	m_SceneService = IService::Create<SceneService>();

		m_TimerService = IService::Create<SdlTimer>();
		m_InputService = IService::Create<SdlInput>();
		
		m_MathService = IService::Create<MathService>();

		m_IsInitialized = true;
		return true;
}

void Engine::Start()
{
	if (m_IsInitialized && !m_IsRunning)
	{
		m_LoggingService->Log("BartEngine2d Version " + string(BART_ENGINE_VERSION_STRING));
		m_IsRunning = true;
		float lastTime = m_TimerService->GetTime();

		while (m_IsRunning)
		{
			const float start = m_TimerService->GetTime();

			ProcessInput();
			Update((start - lastTime) * 0.0001f);
			Render();

			m_TimerService->Sleep(start + FRAME_TARGET_TIME - m_TimerService->GetTime());
			lastTime = start;
		}

		Destroy();
	}
}

void Engine::Stop()
{
	m_IsRunning = false;
}

void Engine::Destroy()
{
	IService::Destroy<IMaths>(m_MathService);
	IService::Destroy<IScene>(m_SceneService);
	IService::Destroy<IInput>(m_InputService);
	IService::Destroy<ITimer>(m_TimerService);
	IService::Destroy<IGraphics>(m_GraphicService);
	IService::Destroy<ILogger>(m_LoggingService);
}

void Engine::ProcessInput()
{
	m_InputService->PoolEvents();

	if (m_InputService->IsKeyDown(KEY_ESCAPE))
	{
		Stop();
	}

#ifdef _DEBUG
	if (m_InputService->IsKeyDown(KEY_F1))
	{
		if (!m_F1Pressed)
		{
			m_F1Pressed = true;
			m_GraphicService->SetWindowState(WINDOWED);
		}
	}
	else
	{
		m_F1Pressed = false;
	}

	if (m_InputService->IsKeyDown(KEY_F2))
	{
		if (!m_F2Pressed)
		{
			m_F2Pressed = true;
			m_GraphicService->SetWindowState(BORDERLESS);
		}
	}
	else
	{
		m_F2Pressed = false;
	}

	if (m_InputService->IsKeyDown(KEY_F3))
	{
		if (!m_F3Pressed)
		{
			m_F3Pressed = true;
			m_GraphicService->SetWindowState(FULLSCREEN);
		}
	}
	else
	{
		m_F3Pressed = false;
	}
#endif
}

void Engine::Update(const float deltaTime) const
{
	m_SceneService->Update(deltaTime);
}

void Engine::Render() const
{
	m_GraphicService->Clear();
	m_SceneService->Render();
	m_GraphicService->Present();
}