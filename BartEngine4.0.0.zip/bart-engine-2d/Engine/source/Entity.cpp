#include <Entity.h>
#include <tinyxml.h>
#include <Engine.h>

void Entity::Update(const float deltaTime)
{
	if (m_IsActive)
	{
		for (Component* component : m_Components)
		{
			component->Update(deltaTime);
		}
	}
}

void Entity::Render()
{
	if (m_IsActive)
	{
		for (Component* component : m_Components)
		{
			component->Render();
		}
	}
}

void Entity::Destroy()
{
	m_IsActive = false;
	for (Component* component : m_Components)
	{
		component->Destroy();
		delete component;
	}
	m_Components.clear();
}

void Entity::Start()
{
	if (m_IsActive)
	{
		for (Component* component : m_Components)
		{
			component->Start();
		}
	}
}

void Entity::SetActive(const bool active)
{
	if (m_IsActive != active)
	{
		m_IsActive = active;
		if (m_IsActive)
		{
			for (Component* component : m_Components)
			{
				component->OnEnable();
			}
		}
		else
		{
			for (Component* component : m_Components)
			{
				component->OnDisable();
			}
		}
	}
}