#include <Bart2d.h>
#include <SceneService.h>
#include <tinyxml.h>
#include <Engine.h>

bool SceneService::Initialize()
{
	return true;
}

void SceneService::Destroy()
{
	Unload();
}

void SceneService::Load(const string& name)
{
}

void SceneService::Unload()
{
	m_CurrentScene.clear();

	for (Entity* entity : m_StartingEntities)
	{
		delete entity;
	}

	m_StartingEntities.clear();

	for (Entity* entity : m_RunningEntities)
	{
		entity->Destroy();
		delete entity;
	}

	m_RunningEntities.clear();
	m_EntityByNames.clear();
	m_EntityByLayer.clear();
}

void SceneService::Update(const float deltaTime)
{
	for (Entity* entity : m_RunningEntities)
	{
		entity->Update(deltaTime);
	}

	if (m_StartingEntities.size() > 0)
	{
		vector<Entity*> entities = m_StartingEntities;
		m_StartingEntities.clear();

		for (Entity* entity : entities)
		{
			m_RunningEntities.emplace_back(entity);
			entity->Start();
		}
	}
}

void SceneService::Render()
{
}

Entity* SceneService::AddEntity(const string& name, const string& layer)
{
	Entity* entity = new Entity();
	m_StartingEntities.emplace_back(entity);
	m_EntityByNames[name] = entity;
	return entity;
}

Entity* SceneService::FindEntity(const string& name)
{
	if (m_EntityByNames.count(name) > 0)
	{
		return m_EntityByNames[name];
	}

	return nullptr;
}